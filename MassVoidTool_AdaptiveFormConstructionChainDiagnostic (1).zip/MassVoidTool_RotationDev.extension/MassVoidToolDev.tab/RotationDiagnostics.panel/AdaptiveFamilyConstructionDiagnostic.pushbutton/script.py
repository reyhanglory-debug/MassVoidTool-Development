# -*- coding: utf-8 -*-
"""
Adaptive Family Construction Diagnostic
------------------------------------------------------------------
TUJUAN -- SATU dan HANYA SATU

AdaptiveFamilyGeometryDependencyDiagnostic (sesi lalu) sudah mencoba
memetakan dependency Point<->Form, tetapi run terbaru pada family
"Tinggi Kaki" menunjukkan bahwa asumsi signature-nya SALAH:

    IsAdaptiveComponentFamily(work_doc) -> FAILED: "expected Family,
    got Document" (signature sebenarnya BUKAN (Document))

    GetAdaptivePoints(work_doc) -> FAILED: "'type' object has no
    attribute 'GetAdaptivePoints'" (method ini TIDAK ADA di runtime
    CLR type ini -- bukan hanya gagal dipanggil, memang tidak ada)

Karena itu, PERTANYAAN SEKARANG BUKAN LAGI tentang rotation algorithm
(Rodrigues rotation dan SetCoordinateSystem() SUDAH terbukti benar di
sesi-sesi sebelumnya). Pertanyaan sekarang:

    Apa CONSTRUCTION CHAIN internal family "Tinggi Kaki" yang
    menjelaskan mengapa hanya SEBAGIAN geometry mengikuti perubahan
    Adaptive Point/frame, sedangkan body utama tidak mengalami rigid
    rotation penuh?

Tool ini menjawabnya dengan DUA prinsip ketat:
1. TIDAK ADA signature API yang diasumsikan. Setiap method
   AdaptiveComponentFamilyUtils yang dipanggil, signature-nya
   ditemukan lebih dulu lewat .NET reflection (System.Reflection)
   terhadap CLR type sebenarnya di runtime INI -- bukan dari nama
   method yang pernah dipakai di diagnostic sebelumnya, bukan dari
   dokumentasi/training data. Argumen HANYA disuplai dari objek
   runtime nyata yang benar-benar ada (Document, OwnerFamily,
   ElementId sebuah ReferencePoint yang sudah ada) -- kalau tipe
   parameter tidak cocok dengan objek yang tersedia, panggilan
   ditandai SKIPPED, tidak pernah ditebak.
2. TIDAK ADA kesimpulan root-cause dari nama elemen atau dari
   GetDependentElements() saja. Setiap hubungan yang dicetak diberi
   label evidence yang eksplisit (direct attribute vs
   GetDependentElements() POSITION/EXISTENCE vs BFS multi-hop vs
   UNKNOWN). Bagian akhir memisahkan tegas VERIFIED EVIDENCE dari
   HYPOTHESIS -- tidak pernah mencampur keduanya.

Tool ini TIDAK menggantikan, TIDAK mewarisi kode dari, dan TIDAK
memodifikasi diagnostic mana pun sebelumnya (termasuk
AdaptiveFamilyGeometryDependencyDiagnostic, satu-satunya diagnostic
lain yang masih ada di package ini). Berdiri sendiri, sepenuhnya
terpisah -- reflection engine di file ini ditulis ulang secara
independen (pola yang sama dengan AdaptiveFamilyApiCompatibilityDiagnostic
versi sebelumnya, tetapi tidak mengimpor/memanggil file itu, yang
sudah tidak ada lagi di package ini).

------------------------------------------------------------------
LOCKED FILES -- HANYA fungsi baca-nama yang dipanggil apa adanya
------------------------------------------------------------------
    mass_panel_core.py  (get_family_name, get_type_name -- HANYA
                          dipakai untuk membaca nama Family/Type dari
                          FamilySymbol saat memilih family di mode
                          Project Document; TIDAK ADA fungsi core
                          lain yang dipanggil di file ini)

mass_panel_rotation.py, mass_panel_storage.py, mass_panel_storage_v5.py
TIDAK di-import sama sekali. Tidak ada Extensible Storage dibaca/
ditulis, tidak ada Schema/Entity apa pun.

------------------------------------------------------------------
READ-ONLY GUARANTEE
------------------------------------------------------------------
Tool ini TIDAK PERNAH memanggil (dicek eksplisit lewat static audit
grep juga, lihat header STATIC AUDIT di percakapan):
    ElementTransformUtils.RotateElement()
    Transform.CreateRotation() / CreateRotationAtPoint()
    ReferencePoint.SetCoordinateSystem()
    AdaptiveComponentFamilyUtils.SetPointOrientationType()
    AdaptiveComponentFamilyUtils.SetPointConstraintType()
    AdaptiveComponentFamilyUtils.MakeAdaptivePoint()
    Document.Delete() / Element.Delete()
Tidak membuat, menghapus, atau mengubah geometry, ReferencePlane,
Sketch, parameter, atau elemen family apa pun. Reflection GetMethods()
+ Invoke() HANYA dipakai pada method yang namanya diverifikasi
read-only (Is*/Get*) -- method Set*/Make* SENGAJA tidak pernah
diinvestigasi apalagi dipanggil.

Family document dibuka dengan cara yang sama seperti
AdaptiveFamilyGeometryDependencyDiagnostic: kalau document aktif
sudah Family Document, dipakai langsung; kalau document aktif Project
Document, dibuka via Document.EditFamily() (in-memory, TIDAK PERNAH
disimpan, TIDAK PERNAH di-load-back ke project), dan SELALU ditutup
tanpa disimpan (Close(False)) di blok finally -- bahkan kalau terjadi
error di tengah jalan.

Satu-satunya operasi yang membutuhkan Transaction terbuka adalah
Element.GetDependentElements() (kebutuhan historis sebagian versi
Revit API, konvensi yang sama dengan diagnostic sebelumnya) --
Transaction tersebut SELALU di-RollBack() di blok finally, TIDAK
PERNAH di-Commit.

------------------------------------------------------------------
KENAPA REFLECTION, BUKAN NAMA METHOD YANG "PERNAH DIPAKAI"
------------------------------------------------------------------
Sesi sebelumnya salah berasumsi bahwa GetAdaptivePoints(doc) dan
IsAdaptiveComponentFamily(doc) adalah signature yang benar -- run
terbaru pada Tinggi Kaki MEMBUKTIKAN keduanya salah. Karena itu tool
ini:
1. Meresolusi CLR Type dari DB.AdaptiveComponentFamilyUtils via
   clr.GetClrType(), lalu memanggil GetMethods() dengan BindingFlags
   Public|NonPublic|Static|Instance -- mencetak SETIAP nama method
   yang benar-benar ada pada runtime ini, sebelum mengasumsikan apa
   pun.
2. Untuk setiap method yang namanya mengandung "Point" atau "Adaptive"
   (dan BUKAN Set*/Make*, read-only saja), signature-nya (parameter
   types + return type) dibaca lewat MethodInfo.GetParameters() /
   .ReturnType -- dicetak apa adanya.
3. Invocation HANYA dicoba kalau setiap parameter method tersebut
   punya tipe yang cocok PERSIS dengan salah satu dari: Document
   (work_doc), Family (owner_family), atau ElementId (sebuah
   ReferencePoint yang sudah ada di document). Tidak pernah menebak
   FamilySymbol atau tipe lain.
4. TargetInvocationException di-unwrap ke InnerException supaya
   exception .NET yang sebenarnya (bukan wrapper reflection) yang
   dilaporkan -- persis seperti error "expected Family, got Document"
   yang dilaporkan user, yang membuktikan reflection-based approach
   ini memang perlu untuk menemukan signature yang benar.

------------------------------------------------------------------
YANG SENGAJA TIDAK DILAKUKAN DI SINI (per instruksi user)
------------------------------------------------------------------
- TIDAK ADA perubahan pada mass_panel_core.py, mass_panel_rotation.py,
  mass_panel_storage.py, mass_panel_storage_v5.py, production file,
  atau AdaptiveFamilyGeometryDependencyDiagnostic.
- TIDAK ADA geometry/ReferencePlane/Sketch/parameter yang dibuat,
  dihapus, atau diubah.
- TIDAK ADA SetCoordinateSystem(), SetPointOrientationType(),
  RotateElement(), CreateRotation()/CreateRotationAtPoint(), atau
  rotation transform apa pun diterapkan pada family.
- TIDAK ADA Extensible Storage / Schema / Entity apa pun.
- TIDAK ADA family di-Save() atau di-load-back ke project.
- TIDAK ADA root-cause FINAL disimpulkan. "Adaptive Point count = 0"
  TIDAK PERNAH dicetak sebagai bukti tidak-ada-Adaptive-Point kalau
  discovery-nya sendiri UNRESOLVED -- selalu dibedakan tegas antara
  "0 ditemukan, discovery berhasil" vs "discovery UNRESOLVED/UNKNOWN".
"""

import System
import clr
from pyrevit import revit, DB, forms, script
from System.Reflection import BindingFlags

from mass_panel_core import get_family_name, get_type_name

doc = revit.doc
uidoc = revit.uidoc
output = script.get_output()

MAX_BFS_DEPTH = 6
MAX_BFS_VISITED = 800

output.print_md("## Adaptive Family Construction Diagnostic")
output.print_md(
    "Read-only, development-only. TIDAK ADA signature API yang diasumsikan -- setiap "
    "panggilan AdaptiveComponentFamilyUtils dicari lebih dulu lewat .NET reflection pada "
    "runtime ini. TIDAK ADA geometry/family/parameter yang dibuat, dihapus, atau diubah. "
    "TIDAK ADA kesimpulan root-cause final dicetak.")


# ==================================================================
# Generic read-only helpers.
# ==================================================================
def fmt_eid(eid):
    if eid is None:
        return "None"
    try:
        return str(int(eid.Value))
    except Exception:
        pass
    try:
        return str(int(eid.IntegerValue))
    except Exception:
        pass
    return str(eid)


def fmt_xyz(p):
    if p is None:
        return "None"
    try:
        return "({:.6f}, {:.6f}, {:.6f})".format(p.X, p.Y, p.Z)
    except Exception:
        return str(p)


def safe_attr(obj, name):
    try:
        return getattr(obj, name), None
    except Exception as ex:
        return None, "{}: {}".format(type(ex).__name__, ex)


def safe_call(fn):
    try:
        return fn(), None
    except Exception as ex:
        return None, "{}: {}".format(type(ex).__name__, ex)


def clr_full_name(py_obj_or_type):
    try:
        t = clr.GetClrType(py_obj_or_type)
        full_name, _ = safe_attr(t, "FullName")
        namespace, _ = safe_attr(t, "Namespace")
        return full_name, namespace, t, None
    except Exception as ex:
        return None, None, None, "{}: {}".format(type(ex).__name__, ex)


# ==================================================================
# STEP 0: Obtain a Family Document -- read-only in both modes (see
# docstring).
# ==================================================================
family_doc_opened_here = False
work_doc = None

if doc.IsFamilyDocument:
    work_doc = doc
    output.print_md("\n**Mode: document aktif SUDAH Family Document** -- dipakai langsung.")
else:
    output.print_md("\n**Mode: document aktif adalah Project Document** -- tool akan membuka "
                     "SATU Adaptive Family via Document.EditFamily() (in-memory, read-only, "
                     "TIDAK disimpan, TIDAK di-load-back ke project).")

    candidates = DB.FilteredElementCollector(doc).OfClass(DB.FamilySymbol).ToElements()
    family_map = {}
    for sym in candidates:
        try:
            if sym.Family.FamilyPlacementType != DB.FamilyPlacementType.Adaptive:
                continue
        except Exception:
            continue
        fam_name = get_family_name(sym)
        if fam_name not in family_map:
            family_map[fam_name] = sym.Family

    if not family_map:
        forms.alert(
            "Tidak ada Adaptive Family yang loaded di project ini. Load family yang ingin "
            "diinspeksi (mis. Tinggi Kaki) lalu jalankan ulang tool ini, atau buka .rfa-nya "
            "langsung di Family Editor sebelum menjalankan tool ini.",
            title="Tidak ada Adaptive Family", exitscript=True)

    fam_labels = sorted(family_map.keys())
    chosen_fam_label = forms.SelectFromList.show(
        fam_labels,
        title="PILIH Adaptive Family untuk dibuka & diinspeksi di Family Editor "
              "(mis. 'Tinggi Kaki') -- Anda yang menentukan",
        button_name="Buka di Family Editor (read-only)", multiselect=False)
    if chosen_fam_label is None:
        script.exit()

    target_family = family_map[chosen_fam_label]
    output.print_md("Family dipilih: **{}** (dipilih manual oleh user).".format(chosen_fam_label))

    try:
        work_doc = doc.EditFamily(target_family)
        family_doc_opened_here = True
    except Exception as ex:
        output.print_md("**GAGAL membuka family via Document.EditFamily(): {}**".format(ex))
        script.exit()

    output.print_md("Family document dibuka in-memory via Document.EditFamily() -- TIDAK "
                     "disimpan, TIDAK di-load-back ke project. Akan ditutup tanpa disimpan "
                     "(Close(False)) di akhir tool ini.")

verified_evidence = []   # list of str, for final summary section
unknown_items = []       # list of str
hypotheses = []          # list of str

try:
    is_fam_doc = work_doc.IsFamilyDocument
    if not is_fam_doc:
        output.print_md("\n**STOP -- document obtained is NOT a Family Document.**")
        script.exit()

    owner_family, owner_err = safe_attr(work_doc, "OwnerFamily")
    if owner_err or owner_family is None:
        output.print_md("\n**STOP -- OwnerFamily FAILED to read ({})** -- reflection calls below "
                         "need a real Family object; cannot continue safely.".format(owner_err))
        script.exit()

    # ==============================================================
    # === FAMILY IDENTITY ===
    # ==============================================================
    output.print_md("\n---\n### === FAMILY IDENTITY ===")

    output.print_md("- Document Title: **{}**".format(work_doc.Title))
    output.print_md("- IsFamilyDocument: **{}**".format(is_fam_doc))

    try:
        fam_name_disp = owner_family.Name
    except Exception as ex:
        fam_name_disp = "UNKNOWN (.Name raised: {})".format(ex)
    output.print_md("- OwnerFamily.Name: **{}**".format(fam_name_disp))
    verified_evidence.append("OwnerFamily.Name = {}".format(fam_name_disp))

    cat, cat_err = safe_call(lambda: owner_family.FamilyCategory.Name)
    output.print_md("- FamilyCategory: **{}**".format(cat if not cat_err else "UNKNOWN ({})".format(cat_err)))

    placement_type, pt_err = safe_attr(owner_family, "FamilyPlacementType")
    output.print_md("- FamilyPlacementType (raw): **{}**".format(
        placement_type if not pt_err else "UNKNOWN ({})".format(pt_err)))
    if not pt_err:
        verified_evidence.append("FamilyPlacementType = {}".format(placement_type))
        enum_full_name, enum_ns, enum_clr_type, enum_err = clr_full_name(DB.FamilyPlacementType)
        if not enum_err:
            try:
                names = list(enum_clr_type.GetEnumNames())
                output.print_md("  Real enum member names (System.Enum.GetNames, this runtime): {}".format(
                    ", ".join(str(n) for n in names)))
            except Exception as ex:
                output.print_md("  GetEnumNames() FAILED: {}".format(ex))

    # --------------------------------------------------------------
    # AdaptiveComponentFamilyUtils -- CLR resolution + full method list.
    # --------------------------------------------------------------
    output.print_md("\n#### AdaptiveComponentFamilyUtils -- CLR reflection (no assumed signatures)")

    acfu_clr_type = None
    full_name, namespace, acfu_clr_type, clr_err = clr_full_name(DB.AdaptiveComponentFamilyUtils)
    if clr_err:
        output.print_md("clr.GetClrType(DB.AdaptiveComponentFamilyUtils) FAILED: {}".format(clr_err))
        unknown_items.append("AdaptiveComponentFamilyUtils CLR type could not be resolved: {}".format(clr_err))
    else:
        output.print_md("- CLR Type FullName = **{}**".format(full_name))

    all_method_infos = []
    if acfu_clr_type is not None:
        try:
            flags = (BindingFlags.Public | BindingFlags.NonPublic |
                     BindingFlags.Static | BindingFlags.Instance)
            all_method_infos = list(acfu_clr_type.GetMethods(flags))
            method_names_sorted = sorted(set(m.Name for m in all_method_infos))
            output.print_md("- Reflection found **{}** method(s) total ({} distinct name(s)).".format(
                len(all_method_infos), len(method_names_sorted)))
            output.print_md("- Full method name list (ground truth for THIS runtime): {}".format(
                ", ".join(method_names_sorted)))
            verified_evidence.append(
                "AdaptiveComponentFamilyUtils real method names on this runtime = {}".format(
                    ", ".join(method_names_sorted)))
        except Exception as ex:
            output.print_md("GetMethods() FAILED: {}".format(ex))
            unknown_items.append("AdaptiveComponentFamilyUtils.GetMethods() failed: {}".format(ex))

    def describe_method(m):
        try:
            params = list(m.GetParameters())
            param_descr = ", ".join("{} {}".format(p.ParameterType.FullName, p.Name) for p in params)
        except Exception as ex:
            param_descr = "PARAM READ FAILED: {}".format(ex)
        try:
            ret = m.ReturnType.FullName
        except Exception:
            ret = "?"
        return "{} {}({})".format(ret, m.Name, param_descr)

    def resolve_arg_for_param(p, work_doc, owner_family, point_id):
        """Only ever supplies work_doc / owner_family / point_id when the
        parameter's exact CLR type matches. Never guesses."""
        try:
            type_full = p.ParameterType.FullName or ""
        except Exception as ex:
            return None, False, "ParameterType.FullName read FAILED: {}".format(ex)
        if type_full == "Autodesk.Revit.DB.Document":
            return work_doc, True, "work_doc"
        if type_full == "Autodesk.Revit.DB.Family":
            if owner_family is not None:
                return owner_family, True, "owner_family (work_doc.OwnerFamily)"
            return None, False, "parameter type is Family, but OwnerFamily unavailable"
        if type_full == "Autodesk.Revit.DB.ElementId":
            if point_id is not None:
                return point_id, True, "point_id (ElementId {})".format(fmt_eid(point_id))
            return None, False, "parameter type is ElementId, but no point_id supplied for this call"
        return None, False, "no known runtime object available for parameter type '{}'".format(type_full)

    def build_args_for(method_info, point_id=None):
        try:
            params = list(method_info.GetParameters())
        except Exception as ex:
            return None, None, "GetParameters() FAILED: {}".format(ex)
        args, labels = [], []
        for p in params:
            value, ok, info = resolve_arg_for_param(p, work_doc, owner_family, point_id)
            if not ok:
                return None, None, info
            args.append(value)
            labels.append(info)
        return args, labels, None

    def invoke_via_reflection(method_info, args):
        try:
            net_args = System.Array[System.Object](args) if args else System.Array[System.Object](0)
            result = method_info.Invoke(None, net_args)
            return result, None, None
        except Exception as ex:
            inner = getattr(ex, "InnerException", None)
            if inner is not None:
                return None, type(inner).__name__, str(inner)
            return None, type(ex).__name__, str(ex)

    def call_method_all_overloads(method_name, point_id=None):
        """Try every overload of method_name found by reflection. Returns
        (success_value, success_return_type, detail_lines). Never guesses
        an argument. Read-only names only (Is*/Get*) -- caller enforces
        this by never passing Set*/Make* names in here."""
        matches = [m for m in all_method_infos if m.Name == method_name]
        lines = []
        if not matches:
            lines.append("METHOD NOT AVAILABLE on this runtime CLR type.")
            return None, None, lines
        for i, m in enumerate(matches):
            sig = describe_method(m)
            lines.append("Overload #{}: `{}`".format(i + 1, sig))
            args, labels, skip_reason = build_args_for(m, point_id)
            if skip_reason:
                lines.append("  Invocation = SKIPPED ({})".format(skip_reason))
                continue
            value, exc_type, exc_msg = invoke_via_reflection(m, args)
            if exc_type is None:
                lines.append("  Invocation = SUCCESS. Raw result = {}".format(value))
                return value, m.ReturnType, lines
            lines.append("  Invocation = FAILED -- {}: {}".format(exc_type, exc_msg))
        return None, None, lines

    # --------------------------------------------------------------
    # IsAdaptiveComponentFamily -- reflection-verified signature.
    # --------------------------------------------------------------
    output.print_md("\n#### IsAdaptiveComponentFamily (reflection-verified)")
    iacf_value, iacf_ret_type, iacf_lines = call_method_all_overloads("IsAdaptiveComponentFamily")
    for l in iacf_lines:
        output.print_md("- {}".format(l))
    if iacf_value is not None:
        try:
            interpreted_iacf = bool(iacf_value)
            output.print_md("- **IsAdaptiveComponentFamily = {}**".format(interpreted_iacf))
            verified_evidence.append("IsAdaptiveComponentFamily(OwnerFamily) = {} (reflection-verified "
                                      "signature, actual API call succeeded)".format(interpreted_iacf))
        except Exception:
            interpreted_iacf = None
            unknown_items.append("IsAdaptiveComponentFamily returned a value but could not be interpreted as bool.")
    else:
        interpreted_iacf = None
        output.print_md("- **IsAdaptiveComponentFamily = UNKNOWN** (no successful invocation -- see detail above; "
                         "NOT interpreted as False/non-adaptive).")
        unknown_items.append("IsAdaptiveComponentFamily could not be determined (see overload attempts above).")

    # --------------------------------------------------------------
    # Broad reflection scan for ANY Point/Adaptive-related read-only
    # method -- not limited to names used in earlier sessions.
    # --------------------------------------------------------------
    output.print_md("\n#### Broad scan: all read-only methods with 'Point' or 'Adaptive' in the name")
    candidate_names = sorted(set(
        m.Name for m in all_method_infos
        if ("point" in m.Name.lower() or "adaptive" in m.Name.lower())
        and not m.Name.lower().startswith("set")
        and not m.Name.lower().startswith("make")
    ))
    output.print_md("Candidate read-only method names found = {}".format(
        ", ".join(candidate_names) if candidate_names else "(none)"))

    # Methods callable with ONLY work_doc/owner_family (no point id) --
    # candidates for POINT DISCOVERY (an ElementId-collection-returning
    # method would be the real replacement for the non-existent
    # GetAdaptivePoints()).
    doc_or_family_only_results = {}
    for name in candidate_names:
        matches = [m for m in all_method_infos if m.Name == name]
        # Only attempt overloads whose parameters are ALL resolvable
        # without a point_id (i.e. Document/Family only).
        attempted = False
        for m in matches:
            try:
                params = list(m.GetParameters())
            except Exception:
                continue
            if len(params) == 0:
                attempted = True
                value, exc_type, exc_msg = invoke_via_reflection(m, [])
                doc_or_family_only_results[name] = (value, exc_type, exc_msg, describe_method(m))
                break
            type_names = []
            ok_all = True
            for p in params:
                try:
                    type_names.append(p.ParameterType.FullName)
                except Exception:
                    ok_all = False
                    break
            if not ok_all:
                continue
            if all(t in ("Autodesk.Revit.DB.Document", "Autodesk.Revit.DB.Family") for t in type_names):
                args = []
                for t in type_names:
                    args.append(work_doc if t == "Autodesk.Revit.DB.Document" else owner_family)
                attempted = True
                value, exc_type, exc_msg = invoke_via_reflection(m, args)
                doc_or_family_only_results[name] = (value, exc_type, exc_msg, describe_method(m))
                break

    point_discovery_candidates = {}  # name -> list of ElementId found
    for name, (value, exc_type, exc_msg, sig) in doc_or_family_only_results.items():
        output.print_md("- **{}** -- `{}`".format(name, sig))
        if exc_type is not None:
            output.print_md("  Invocation = FAILED -- {}: {}".format(exc_type, exc_msg))
            continue
        output.print_md("  Invocation = SUCCESS. Raw result = {}".format(value))
        # Try to interpret as an enumerable collection of ElementId.
        found_ids = []
        try:
            for item in value:
                try:
                    if isinstance(item, DB.ElementId):
                        found_ids.append(item)
                except Exception:
                    continue
        except Exception:
            pass
        if found_ids:
            output.print_md("  Interpreted as ElementId collection: {} id(s) = {}".format(
                len(found_ids), ", ".join(fmt_eid(i) for i in found_ids)))
            point_discovery_candidates[name] = found_ids
            verified_evidence.append("{}(...) returned {} ElementId(s) via reflection-verified call".format(
                name, len(found_ids)))

    if not point_discovery_candidates:
        output.print_md("No method taking only (Document/Family) returned an ElementId collection on this "
                         "runtime. Point discovery below falls back to FilteredElementCollector(work_doc)."
                         "OfClass(DB.ReferencePoint), classified per-point via reflection (see ADAPTIVE POINTS).")
        unknown_items.append("No AdaptiveComponentFamilyUtils method returning an ElementId collection of "
                              "adaptive points was found on this runtime -- point discovery relies on "
                              "FilteredElementCollector + per-point classification instead.")

    # ==============================================================
    # === ADAPTIVE POINTS ===
    # ==============================================================
    output.print_md("\n---\n### === ADAPTIVE POINTS ===")

    all_ref_points, rp_collect_err = safe_call(
        lambda: list(DB.FilteredElementCollector(work_doc).OfClass(DB.ReferencePoint)))
    if rp_collect_err:
        output.print_md("FilteredElementCollector(work_doc).OfClass(DB.ReferencePoint) FAILED: {}".format(rp_collect_err))
        all_ref_points = []
        unknown_items.append("ReferencePoint collection failed: {}".format(rp_collect_err))
    else:
        output.print_md("FilteredElementCollector found **{}** ReferencePoint element(s) in this document "
                         "(this counts ALL ReferencePoint elements, not only ones confirmed adaptive -- "
                         "see classification below).".format(len(all_ref_points)))

    classification_names = ["IsAdaptivePoint", "IsAdaptivePlacementPoint", "IsAdaptiveShapeHandlePoint"]
    # NOTE: rewritten as an explicit for-loop (was a dict comprehension
    # wrapping a generator expression: {n: any(... for m in ...) for n in
    # ...}). IronPython 2.7 has a known scoping bug where a nested
    # comprehension/generator expression loses visibility of the
    # enclosing comprehension's loop variable, raising
    # "NameError: global name 'n' is not defined" at runtime. Explicit
    # for-loops do not have this scoping issue. Semantics unchanged:
    # classification_available[cls_name] = True iff at least one
    # MethodInfo in all_method_infos has that exact .Name.
    classification_available = {}
    for cls_name in classification_names:
        found_method = False
        for m in all_method_infos:
            if m.Name == cls_name:
                found_method = True
                break
        classification_available[cls_name] = found_method
    output.print_md("Classification method availability (reflection-verified): {}".format(
        ", ".join("{}={}".format(n, classification_available[n]) for n in classification_names)))

    points_data = []
    for idx, pt_el in enumerate(all_ref_points):
        pt_id = pt_el.Id
        entry = {"index": idx, "id": pt_id}

        position, pos_err = safe_attr(pt_el, "Position")
        entry["position"] = position
        entry["position_err"] = pos_err

        cs, cs_err = safe_call(lambda el=pt_el: el.GetCoordinateSystem())
        entry["cs"] = cs
        entry["cs_err"] = cs_err

        classification = {}
        is_flagged_adaptive = False
        for cname in classification_names:
            if not classification_available[cname]:
                classification[cname] = ("METHOD NOT AVAILABLE", None)
                continue
            value, ret_type, lines = call_method_all_overloads(cname, point_id=pt_id)
            if value is not None:
                classification[cname] = (value, lines)
                try:
                    if bool(value):
                        is_flagged_adaptive = True
                except Exception:
                    pass
            else:
                classification[cname] = ("UNRESOLVED", lines)
        entry["classification"] = classification
        entry["is_flagged_adaptive"] = is_flagged_adaptive

        placement_number, pn_lines = None, []
        pn_value, pn_ret_type, pn_lines = call_method_all_overloads("GetPlacementNumber", point_id=pt_id)
        entry["placement_number_api"] = pn_value
        entry["placement_number_api_lines"] = pn_lines

        orient_value, orient_ret_type, orient_lines = call_method_all_overloads("GetPointOrientationType", point_id=pt_id)
        entry["orient_value"] = orient_value
        entry["orient_lines"] = orient_lines

        constraint_value, constraint_ret_type, constraint_lines = call_method_all_overloads("GetPointConstraintType", point_id=pt_id)
        entry["constraint_value"] = constraint_value
        entry["constraint_lines"] = constraint_lines

        points_data.append(entry)

    adaptive_flagged = [p for p in points_data if p["is_flagged_adaptive"]]
    if all_ref_points and not any(classification_available.values()):
        output.print_md("\n**Adaptive Point discovery = UNRESOLVED/UNKNOWN.** {} ReferencePoint element(s) "
                         "exist, but NO classification method (IsAdaptivePoint / IsAdaptivePlacementPoint / "
                         "IsAdaptiveShapeHandlePoint) is available on this runtime to confirm which of them "
                         "are adaptive. **Adaptive Point count is NOT reported as 0** -- it is UNRESOLVED, "
                         "per explicit instruction.".format(len(all_ref_points)))
        unknown_items.append("Adaptive Point discovery UNRESOLVED -- {} ReferencePoint(s) exist but no "
                              "classification method available on this runtime.".format(len(all_ref_points)))
    elif not all_ref_points:
        output.print_md("\n**No ReferencePoint elements found at all** -- FilteredElementCollector returned "
                         "an empty set (not a classification failure; the collection itself found zero).")
    else:
        output.print_md("\nOf {} ReferencePoint(s), {} flagged adaptive by at least one classification "
                         "method (reflection-verified calls, detail per point below).".format(
                             len(all_ref_points), len(adaptive_flagged)))
        verified_evidence.append("{} ReferencePoint(s) found; {} flagged adaptive by reflection-verified "
                                  "classification call(s)".format(len(all_ref_points), len(adaptive_flagged)))

    for entry in points_data:
        idx, pt_id = entry["index"], entry["id"]
        output.print_md("\n**Point #{}** -- ElementId {} (flagged adaptive = {})".format(
            idx, fmt_eid(pt_id), entry["is_flagged_adaptive"]))
        for cname in classification_names:
            value, lines = entry["classification"][cname]
            output.print_md("- {} = {}".format(cname, value))
        if entry["placement_number_api"] is not None:
            output.print_md("- Placement Number (API, GetPlacementNumber, reflection-verified) = **{}**".format(
                entry["placement_number_api"]))
        else:
            output.print_md("- Placement Number (API) = UNRESOLVED. Fallback = list-order index {} -- "
                             "**NOT confirmed topology order**, only enumeration order from "
                             "FilteredElementCollector (no ordering guarantee).".format(idx))
        if entry["position_err"]:
            output.print_md("- Position: FAILED ({})".format(entry["position_err"]))
        else:
            output.print_md("- Position: {}".format(fmt_xyz(entry["position"])))
        if entry["cs_err"]:
            output.print_md("- CoordinateSystem: FAILED ({})".format(entry["cs_err"]))
        else:
            cs = entry["cs"]
            output.print_md("- CoordinateSystem Origin = {}".format(fmt_xyz(cs.Origin)))
            output.print_md("- BasisX = {}".format(fmt_xyz(cs.BasisX)))
            output.print_md("- BasisY = {}".format(fmt_xyz(cs.BasisY)))
            output.print_md("- BasisZ = {}".format(fmt_xyz(cs.BasisZ)))
        output.print_md("- PointOrientationType (GetPointOrientationType, reflection-verified) = {}".format(
            entry["orient_value"] if entry["orient_value"] is not None else "UNRESOLVED"))
        output.print_md("- PointConstraintType (GetPointConstraintType, reflection-verified) = {}".format(
            entry["constraint_value"] if entry["constraint_value"] is not None else "UNRESOLVED"))

    # ==============================================================
    # === REFERENCE PLANES ===
    # ==============================================================
    output.print_md("\n---\n### === REFERENCE PLANES ===")

    ref_planes = list(DB.FilteredElementCollector(work_doc).OfClass(DB.ReferencePlane))
    if not ref_planes:
        output.print_md("No ReferencePlane elements found.")

    ref_plane_data = []
    for rp in ref_planes:
        rp_id_str = fmt_eid(rp.Id)
        name, name_err = safe_attr(rp, "Name")
        plane_obj, plane_err = safe_call(lambda r=rp: r.GetPlane())
        origin = plane_obj.Origin if (plane_obj is not None) else None
        normal = plane_obj.Normal if (plane_obj is not None) else None
        free_end, fe_err = safe_attr(rp, "FreeEnd")
        bubble_end, be_err = safe_attr(rp, "BubbleEnd")
        ref_plane_data.append({"id": rp_id_str, "element": rp, "name": name if not name_err else "UNKNOWN"})

        output.print_md("\n**ReferencePlane {}** -- \"{}\"".format(
            rp_id_str, name if not name_err else "UNKNOWN"))
        if not fe_err and not be_err:
            output.print_md("- BubbleEnd = {}, FreeEnd = {}".format(fmt_xyz(bubble_end), fmt_xyz(free_end)))
        if plane_err:
            output.print_md("- Plane Origin/Normal: FAILED ({})".format(plane_err))
        else:
            output.print_md("- Plane Origin = {}".format(fmt_xyz(origin)))
            output.print_md("- Plane Normal = {}".format(fmt_xyz(normal)))
        output.print_md("- Plane coordinate system (BasisX/BasisY beyond Normal): UNKNOWN -- Plane object "
                         "exposes Origin/Normal/XVec/YVec; not all Revit API versions expose all three "
                         "consistently on ReferencePlane.GetPlane() -- attempted below, not assumed.")
        xvec, xvec_err = safe_attr(plane_obj, "XVec") if plane_obj is not None else (None, "no plane object")
        yvec, yvec_err = safe_attr(plane_obj, "YVec") if plane_obj is not None else (None, "no plane object")
        if not xvec_err and not yvec_err:
            output.print_md("  XVec = {}, YVec = {}".format(fmt_xyz(xvec), fmt_xyz(yvec)))
        output.print_md("- Dependent elements / Adaptive Point relation: computed in DEPENDENCY EVIDENCE "
                         "section below (GetDependentElements(), POSITION/EXISTENCE only -- NEVER orientation).")

    # ==============================================================
    # === SKETCHES / SKETCH PLANES ===
    # ==============================================================
    output.print_md("\n---\n### === SKETCHES / SKETCH PLANES ===")

    sketches = list(DB.FilteredElementCollector(work_doc).OfClass(DB.Sketch))
    if not sketches:
        output.print_md("No Sketch elements found.")

    sketch_data = []
    for sk in sketches:
        sk_id_str = fmt_eid(sk.Id)
        sketch_plane_id, spid_err = safe_attr(sk, "SketchPlaneId")
        sketch_plane_el = work_doc.GetElement(sketch_plane_id) if (
            not spid_err and sketch_plane_id and sketch_plane_id != DB.ElementId.InvalidElementId) else None

        sp_plane_obj, sp_plane_err = (None, "no SketchPlane element")
        if sketch_plane_el is not None:
            sp_plane_obj, sp_plane_err = safe_call(lambda spe=sketch_plane_el: spe.GetPlane())

        plane_ref, plane_ref_err = (None, "SketchPlane element not resolved")
        if sketch_plane_el is not None:
            plane_ref, plane_ref_err = safe_call(lambda spe=sketch_plane_el: spe.GetPlaneReference())
        referenced_rp_id_str = None
        if not plane_ref_err and plane_ref is not None:
            try:
                referenced_rp_id_str = fmt_eid(plane_ref.ElementId)
            except Exception as ex:
                plane_ref_err = "Reference had no usable ElementId: {}".format(ex)

        profile_curves = []
        profile, profile_err = safe_attr(sk, "Profile")
        if not profile_err and profile is not None:
            try:
                for loop in profile:
                    for curve in loop:
                        c_id = None
                        c_ref, c_ref_err = safe_call(lambda cu=curve: cu.Reference)
                        if not c_ref_err and c_ref is not None:
                            try:
                                c_id = fmt_eid(c_ref.ElementId)
                            except Exception:
                                c_id = None
                        try:
                            start_pt = curve.GetEndPoint(0)
                            end_pt = curve.GetEndPoint(1)
                        except Exception:
                            start_pt = end_pt = None
                        profile_curves.append({
                            "curve_type": curve.GetType().Name,
                            "ref_element_id": c_id,
                            "start": start_pt, "end": end_pt,
                        })
            except Exception as ex:
                profile_err = "Profile read but iteration FAILED: {}".format(ex)

        sketch_data.append({"id": sk_id_str, "element": sk, "sketch_plane_el_id": fmt_eid(sketch_plane_id) if not spid_err else None,
                             "referenced_rp_id_str": referenced_rp_id_str, "profile_curves": profile_curves})

        output.print_md("\n**Sketch {}**".format(sk_id_str))
        output.print_md("- SketchPlane ElementId = {}".format(
            fmt_eid(sketch_plane_id) if not spid_err else "UNKNOWN ({})".format(spid_err)))
        if sp_plane_err:
            output.print_md("- SketchPlane Origin/Normal: FAILED ({})".format(sp_plane_err))
        elif sp_plane_obj is not None:
            output.print_md("- SketchPlane Origin = {}".format(fmt_xyz(sp_plane_obj.Origin)))
            output.print_md("- SketchPlane Normal = {}".format(fmt_xyz(sp_plane_obj.Normal)))
        if plane_ref_err:
            output.print_md("- SketchPlane -> underlying Reference: UNKNOWN ({})".format(plane_ref_err))
        elif referenced_rp_id_str is not None:
            output.print_md("- SketchPlane -> underlying Reference: ElementId **{}** (direct attribute "
                             "GetPlaneReference(), NOT GetDependentElements() -- this IS a confirmed "
                             "structural link, not just position/existence).".format(referenced_rp_id_str))
            verified_evidence.append("Sketch {} SketchPlane is hosted on ReferencePlane/Reference {} "
                                      "(direct GetPlaneReference() attribute)".format(sk_id_str, referenced_rp_id_str))
        else:
            output.print_md("- SketchPlane -> underlying Reference: None (free/global work plane, not hosted "
                             "on a ReferencePlane).")

        if profile_err:
            output.print_md("- Profile: FAILED to enumerate ({})".format(profile_err))
        else:
            output.print_md("- Profile: {} curve(s) found".format(len(profile_curves)))
            for ci, c in enumerate(profile_curves):
                ref_note = "Reference ElementId={}".format(c["ref_element_id"]) if c["ref_element_id"] else "Reference=UNAVAILABLE"
                output.print_md("  - Curve[{}]: type={}, start={}, end={}, {}".format(
                    ci, c["curve_type"], fmt_xyz(c["start"]), fmt_xyz(c["end"]), ref_note))

    # ==============================================================
    # === FORMS ===
    # ==============================================================
    output.print_md("\n---\n### === FORMS ===")

    forms_elems = list(DB.FilteredElementCollector(work_doc).OfClass(DB.GenericForm))
    freeform_elems = []
    try:
        freeform_elems = list(DB.FilteredElementCollector(work_doc).OfClass(DB.FreeFormElement))
    except Exception:
        freeform_elems = []
    all_form_elems = list(forms_elems) + list(freeform_elems)

    nested_instances = list(DB.FilteredElementCollector(work_doc).OfClass(DB.FamilyInstance))

    if not all_form_elems:
        output.print_md("No GenericForm / FreeFormElement found.")

    def collect_solids(geometry_element):
        solids = []
        if geometry_element is None:
            return solids
        for obj in geometry_element:
            if isinstance(obj, DB.Solid):
                try:
                    if obj.Volume > 1e-9:
                        solids.append(obj)
                except Exception:
                    continue
            elif isinstance(obj, DB.GeometryInstance):
                try:
                    inst_geom = obj.GetInstanceGeometry()
                except Exception:
                    continue
                solids.extend(collect_solids(inst_geom))
        return solids

    def geometry_summary(elem):
        result = {"solid_count": 0, "total_volume": 0.0, "centroid": None,
                  "bbox_min": None, "bbox_max": None, "references_available": None, "error": None}
        try:
            opts = DB.Options()
            opts.ComputeReferences = True
            opts.IncludeNonVisibleObjects = False
            opts.DetailLevel = DB.ViewDetailLevel.Fine
            geom = elem.get_Geometry(opts)
            if geom is None:
                result["error"] = "get_Geometry() returned None"
                return result
            solids = collect_solids(geom)
            result["solid_count"] = len(solids)
            total_vol = 0.0
            all_pts = []
            refs_found = False
            weighted_centroid = (0.0, 0.0, 0.0)
            for s in solids:
                try:
                    v = s.Volume
                    total_vol += v
                except Exception:
                    v = 0.0
                try:
                    c = s.ComputeCentroid()
                    weighted_centroid = (weighted_centroid[0] + c.X * v, weighted_centroid[1] + c.Y * v,
                                         weighted_centroid[2] + c.Z * v)
                except Exception:
                    pass
                try:
                    for f in s.Faces:
                        try:
                            if f.Reference is not None:
                                refs_found = True
                        except Exception:
                            pass
                except Exception:
                    pass
                try:
                    for e in s.Edges:
                        try:
                            crv = e.AsCurve()
                            for pt in crv.Tessellate():
                                all_pts.append((pt.X, pt.Y, pt.Z))
                        except Exception:
                            continue
                except Exception:
                    pass
            result["total_volume"] = total_vol
            result["references_available"] = refs_found
            if total_vol > 1e-12:
                result["centroid"] = (weighted_centroid[0] / total_vol, weighted_centroid[1] / total_vol,
                                      weighted_centroid[2] / total_vol)
            if all_pts:
                xs = [p[0] for p in all_pts]
                ys = [p[1] for p in all_pts]
                zs = [p[2] for p in all_pts]
                result["bbox_min"] = (min(xs), min(ys), min(zs))
                result["bbox_max"] = (max(xs), max(ys), max(zs))
        except Exception as ex:
            result["error"] = str(ex)
        return result

    form_summaries = []
    for fe in all_form_elems:
        fe_id_str = fmt_eid(fe.Id)
        runtime_type = fe.GetType().Name
        gs = geometry_summary(fe)
        form_summaries.append({"element": fe, "id": fe_id_str, "runtime_type": runtime_type, "geom": gs})

        output.print_md("\n**{} {}**".format(runtime_type, fe_id_str))
        if gs["error"]:
            output.print_md("- Geometry: FAILED ({})".format(gs["error"]))
        else:
            output.print_md("- Solid count = {}, Volume = {:.6f} ft3".format(gs["solid_count"], gs["total_volume"]))
            if gs["centroid"]:
                output.print_md("- Centroid (volume-weighted) = {}".format(
                    "({:.6f}, {:.6f}, {:.6f})".format(*gs["centroid"])))
            if gs["bbox_min"]:
                output.print_md("- BBox Min = {}, Max = {}".format(
                    "({:.6f}, {:.6f}, {:.6f})".format(*gs["bbox_min"]),
                    "({:.6f}, {:.6f}, {:.6f})".format(*gs["bbox_max"])))
            output.print_md("- Geometry references available = {}".format(gs["references_available"]))

    # ==============================================================
    # === DEPENDENCY EVIDENCE (shared by Reference Planes / Sketches /
    # Forms / Nested Instances) -- Element.GetDependentElements(),
    # wrapped in a Transaction that is ALWAYS rolled back.
    # ==============================================================
    output.print_md("\n---\n### DEPENDENCY EVIDENCE (Element.GetDependentElements() -- "
                     "POSITION/EXISTENCE ONLY, NOT ORIENTATION)")

    point_direct_deps = {}
    point_direct_deps_err = {}
    point_reachable = {}
    point_bfs_truncated = {}

    if points_data:
        t = DB.Transaction(work_doc, "READ-ONLY dependency introspection (always rolled back)")
        t.Start()
        try:
            def get_dependents_of(eid):
                el = work_doc.GetElement(eid)
                if el is None:
                    return None, "GetElement returned None"
                deps, err = safe_call(lambda e=el: list(e.GetDependentElements(None)))
                return deps, err

            for entry in points_data:
                idx, pt_id = entry["index"], entry["id"]
                deps, err = get_dependents_of(pt_id)
                if err:
                    point_direct_deps[idx] = None
                    point_direct_deps_err[idx] = err
                    point_reachable[idx] = set()
                    point_bfs_truncated[idx] = False
                    continue
                dep_keys = set(fmt_eid(d) for d in deps)
                point_direct_deps[idx] = dep_keys
                point_direct_deps_err[idx] = None

                visited = set([fmt_eid(pt_id)]) | set(dep_keys)
                reachable = set(dep_keys)
                frontier = list(deps)
                depth = 0
                truncated = False
                while frontier and depth < MAX_BFS_DEPTH:
                    next_frontier = []
                    for node_id in frontier:
                        n_deps, n_err = get_dependents_of(node_id)
                        if n_err or n_deps is None:
                            continue
                        for nd in n_deps:
                            key = fmt_eid(nd)
                            if key not in visited:
                                visited.add(key)
                                reachable.add(key)
                                next_frontier.append(nd)
                                if len(visited) > MAX_BFS_VISITED:
                                    truncated = True
                                    break
                        if truncated:
                            break
                    if truncated:
                        break
                    frontier = next_frontier
                    depth += 1
                if frontier and depth >= MAX_BFS_DEPTH:
                    truncated = True
                point_reachable[idx] = reachable
                point_bfs_truncated[idx] = truncated

            # Sketch -> dependents (for FORM construction chain, step below).
            sketch_direct_deps = {}
            sketch_direct_deps_err = {}
            for sd in sketch_data:
                deps, err = get_dependents_of(sd["element"].Id)
                if err:
                    sketch_direct_deps[sd["id"]] = None
                    sketch_direct_deps_err[sd["id"]] = err
                else:
                    sketch_direct_deps[sd["id"]] = set(fmt_eid(d) for d in deps)
                    sketch_direct_deps_err[sd["id"]] = None
        finally:
            t.RollBack()
    else:
        sketch_direct_deps = {}
        sketch_direct_deps_err = {}

    output.print_md("*(GetDependentElements() + BFS gathered inside a Transaction that was immediately "
                     "rolled back -- zero changes committed. MAX_BFS_DEPTH={}, MAX_BFS_VISITED={}.)*".format(
                         MAX_BFS_DEPTH, MAX_BFS_VISITED))

    rp_by_id = {r["id"]: r for r in ref_plane_data}
    sketch_by_id = {s["id"]: s for s in sketch_data}
    form_by_id = {f["id"]: f for f in form_summaries}

    # Point -> ReferencePlane relation (for REFERENCE PLANES section).
    for rpd in ref_plane_data:
        touching = [e["index"] for e in points_data if point_reachable.get(e["index"]) and rpd["id"] in point_reachable[e["index"]]]
        rpd["touching_points"] = touching

    output.print_md("\n#### Reference Plane <-> Point relation (BFS reachable-set membership)")
    if not ref_plane_data:
        output.print_md("No ReferencePlane to report.")
    for rpd in ref_plane_data:
        if rpd["touching_points"]:
            output.print_md("- ReferencePlane {} (\"{}\") IS in reachable-set of Point #{} "
                             "(POSITION/EXISTENCE evidence only).".format(
                                 rpd["id"], rpd["name"], ", #".join(str(i) for i in rpd["touching_points"])))
            verified_evidence.append("ReferencePlane {} reachable from Point #{} via GetDependentElements() "
                                      "BFS (POSITION/EXISTENCE)".format(
                                          rpd["id"], ", #".join(str(i) for i in rpd["touching_points"])))
        else:
            output.print_md("- ReferencePlane {} (\"{}\") NOT found in any Point's reachable-set -- classified "
                             "FREE/GLOBAL (no verified adaptive-point dependency evidence).".format(
                                 rpd["id"], rpd["name"]))

    # ==============================================================
    # === FORM CONSTRUCTION MAP ===
    # ==============================================================
    output.print_md("\n---\n### === FORM CONSTRUCTION MAP ===")
    output.print_md("Chain evidence per Form: Form -> Sketch (via Sketch.GetDependentElements() containing "
                     "the Form -- POSITION/EXISTENCE) -> SketchPlane (direct .SketchPlaneId attribute) -> "
                     "ReferencePlane (direct .GetPlaneReference() attribute) -> Point (BFS reachable-set "
                     "membership, POSITION/EXISTENCE). Every '?' is filled ONLY with evidence found above; "
                     "UNKNOWN where no evidence exists.")

    form_construction = {}
    for fs in form_summaries:
        f_id = fs["id"]
        linked_sketch = None
        for sd in sketch_data:
            deps = sketch_direct_deps.get(sd["id"])
            if deps and f_id in deps:
                linked_sketch = sd
                break

        chain = {"form_id": f_id, "sketch": None, "sketch_plane_id": None,
                 "reference_plane_id": None, "point_relation": [], "point_relation_source": None}

        if linked_sketch is not None:
            chain["sketch"] = linked_sketch["id"]
            chain["sketch_plane_id"] = linked_sketch["sketch_plane_el_id"]
            chain["reference_plane_id"] = linked_sketch["referenced_rp_id_str"]
            if linked_sketch["referenced_rp_id_str"]:
                rpd = rp_by_id.get(linked_sketch["referenced_rp_id_str"])
                if rpd is not None and rpd["touching_points"]:
                    chain["point_relation"] = rpd["touching_points"]
                    chain["point_relation_source"] = "via ReferencePlane {} reachable-set membership".format(
                        linked_sketch["referenced_rp_id_str"])

        # Cross-check: direct Point reachable-set membership of the Form
        # itself (independent of the Sketch chain above).
        direct_point_hits = [e["index"] for e in points_data
                              if point_reachable.get(e["index"]) and f_id in point_reachable[e["index"]]]
        chain["direct_point_hits"] = direct_point_hits

        form_construction[f_id] = chain

        output.print_md("\n**Form {}**".format(f_id))
        output.print_md("  Sketch = {}".format(chain["sketch"] if chain["sketch"] else "UNKNOWN (no Sketch "
                         "found whose GetDependentElements() contains this Form)"))
        output.print_md("  SketchPlane = {}".format(chain["sketch_plane_id"] if chain["sketch_plane_id"] else "UNKNOWN"))
        output.print_md("  ReferencePlane = {}".format(chain["reference_plane_id"] if chain["reference_plane_id"] else "UNKNOWN"))
        if chain["point_relation"]:
            output.print_md("  Adaptive Point relation (via Sketch->SketchPlane->ReferencePlane chain) = "
                             "Point #{} ({})".format(", #".join(str(i) for i in chain["point_relation"]),
                                                       chain["point_relation_source"]))
        else:
            output.print_md("  Adaptive Point relation (via Sketch->SketchPlane->ReferencePlane chain) = UNKNOWN")
        output.print_md("  Adaptive Point relation (direct BFS reachable-set membership of Form itself, "
                         "cross-check) = {}".format(
                             "Point #{}".format(", #".join(str(i) for i in direct_point_hits))
                             if direct_point_hits else "NONE FOUND"))
        output.print_md("  Constraints = see DIMENSIONS / ALIGNMENTS / CONSTRAINTS section below for any "
                         "Dimension referencing this Form's Sketch/SketchPlane/ReferencePlane.")

    # ==============================================================
    # === DIMENSIONS / ALIGNMENTS / CONSTRAINTS ===
    # ==============================================================
    output.print_md("\n---\n### === DIMENSIONS / ALIGNMENTS / CONSTRAINTS ===")

    dims, dims_err = safe_call(lambda: list(DB.FilteredElementCollector(work_doc).OfClass(DB.Dimension)))
    if dims_err:
        output.print_md("Dimension collection FAILED: {}".format(dims_err))
        dims = []
    elif not dims:
        output.print_md("No Dimension elements found.")
    else:
        output.print_md("{} Dimension element(s) found.".format(len(dims)))
        known_ids = set(rp_by_id) | set(sketch_by_id) | set(form_by_id) | set(fmt_eid(e["id"]) for e in points_data)
        for d in dims:
            d_id = fmt_eid(d.Id)
            refs, refs_err = safe_call(lambda dd=d: list(dd.References))
            output.print_md("\n**Dimension {}**".format(d_id))
            if refs_err:
                output.print_md("- References: FAILED ({})".format(refs_err))
                continue
            ref_ids = []
            for r in refs:
                try:
                    ref_ids.append(fmt_eid(r.ElementId))
                except Exception:
                    ref_ids.append("UNKNOWN")
            output.print_md("- References ElementId(s) = {}".format(", ".join(ref_ids) if ref_ids else "(none)"))
            hits = [rid for rid in ref_ids if rid in known_ids]
            if hits:
                output.print_md("- Overlaps with known Point/ReferencePlane/Sketch/Form element(s): {}".format(
                    ", ".join(hits)))
            val, val_err = safe_call(lambda dd=d: dd.ValueString)
            output.print_md("- ValueString = {}".format(val if not val_err else "UNKNOWN ({})".format(val_err)))

    output.print_md("\n**Alignments**: UNKNOWN / NOT EXPOSED -- Revit's public API does not expose a "
                     "collectible 'Alignment' element class distinct from Dimension/constraint internals; "
                     "no invented data is reported here.")

    fm, fm_err = safe_attr(work_doc, "FamilyManager")
    if fm_err or fm is None:
        output.print_md("\n**FamilyParameters**: FAILED to read FamilyManager ({})".format(fm_err))
    else:
        params, params_err = safe_call(lambda: list(fm.Parameters))
        if params_err:
            output.print_md("\n**FamilyParameters**: FAILED to enumerate ({})".format(params_err))
        else:
            output.print_md("\n**FamilyParameters**: {} parameter(s) found.".format(len(params)))
            for p in params:
                pname, pname_err = safe_call(lambda pp=p: pp.Definition.Name)
                is_instance, ii_err = safe_attr(p, "IsInstance")
                formula, formula_err = safe_attr(p, "Formula")
                output.print_md("- {} (IsInstance={}, Formula={})".format(
                    pname if not pname_err else "UNKNOWN",
                    is_instance if not ii_err else "UNKNOWN",
                    formula if not formula_err else "UNKNOWN"))

    # ==============================================================
    # === NESTED FAMILIES ===
    # ==============================================================
    output.print_md("\n---\n### === NESTED FAMILIES ===")

    if not nested_instances:
        output.print_md("No nested FamilyInstance elements found.")
    else:
        for ni in nested_instances:
            ni_id_str = fmt_eid(ni.Id)
            sym, sym_err = safe_attr(ni, "Symbol")
            if sym_err or sym is None:
                nested_fam_name = nested_type_name = "UNKNOWN"
            else:
                nested_fam_name = get_family_name(sym)
                nested_type_name = get_type_name(sym)
            transform, tf_err = safe_call(lambda e=ni: e.GetTransform())
            output.print_md("\n**NestedFamilyInstance {}**".format(ni_id_str))
            output.print_md("- Family Name = {}, Type Name = {}".format(nested_fam_name, nested_type_name))
            if tf_err:
                output.print_md("- Transform: FAILED ({})".format(tf_err))
            else:
                output.print_md("- Transform Origin={}, BasisX={}, BasisY={}, BasisZ={}".format(
                    fmt_xyz(transform.Origin), fmt_xyz(transform.BasisX),
                    fmt_xyz(transform.BasisY), fmt_xyz(transform.BasisZ)))
            output.print_md("- Efek transform terhadap rotasi: TIDAK DISIMPULKAN DI SINI -- raw evidence "
                             "saja, lihat POSSIBLE ROOT-CAUSE HYPOTHESES di bawah.")

    # ==============================================================
    # === WHAT TO INSPECT MANUALLY IN FAMILY EDITOR ===
    # ==============================================================
    output.print_md("\n---\n### === WHAT TO INSPECT MANUALLY IN FAMILY EDITOR ===")
    output.print_md("Revit menyediakan tool bawaan **'Select by ID'** (Manage tab -> Inquiry panel, atau "
                     "cari 'Select by ID' di Family Editor) untuk memilih elemen langsung dari ElementId "
                     "yang dicetak di bawah -- ini fitur UI Revit standar, disebutkan di sini sebagai "
                     "panduan navigasi saja, BUKAN evidence API.")

    if not form_summaries:
        output.print_md("No Forms to inspect.")
    for fs in form_summaries:
        chain = form_construction[fs["id"]]
        output.print_md("\n**Form {}** ({})".format(fs["id"], fs["runtime_type"]))
        lines = []
        if chain["sketch"]:
            lines.append("1. Select by ID = {} (Sketch) -> pilih Form ini lalu klik 'Edit Sketch' (kalau "
                          "tersedia) untuk melihat profile curve yang membentuknya.".format(chain["sketch"]))
        else:
            lines.append("1. Sketch TIDAK terbukti secara API (lihat FORM CONSTRUCTION MAP) -- di Family "
                          "Editor, coba pilih Form {} langsung dan cek Properties palette untuk sumber "
                          "geometry-nya (mis. apakah ini FreeFormElement dari solid langsung, bukan Sketch).".format(fs["id"]))
        if chain["reference_plane_id"]:
            lines.append("2. Select by ID = {} (ReferencePlane) -> cek apakah plane ini 'Defines Origin' atau "
                          "dikunci ke Point tertentu lewat dimension/constraint (lihat DIMENSIONS section).".format(
                              chain["reference_plane_id"]))
        if chain["point_relation"]:
            lines.append("3. Point #{} terbukti terhubung ke ReferencePlane di atas via "
                          "GetDependentElements() BFS -- cek Point tersebut di Family Editor (ElementId "
                          "tercetak di bagian ADAPTIVE POINTS) untuk verifikasi visual bahwa memindahkan "
                          "Point tersebut memindahkan ReferencePlane, dan karenanya Form ini.".format(
                              ", #".join(str(i) for i in chain["point_relation"])))
        elif chain["direct_point_hits"]:
            lines.append("3. Form ini terbukti reachable langsung dari Point #{} (bukan lewat Sketch chain) "
                          "-- cek jalur dependency-nya manual di Family Editor.".format(
                              ", #".join(str(i) for i in chain["direct_point_hits"])))
        else:
            lines.append("3. TIDAK ADA evidence dependency ke Point manapun ditemukan untuk Form ini -- "
                          "ini kandidat kuat untuk geometry yang 'terkunci' independen dari Adaptive Point. "
                          "Verifikasi manual: pilih Form ini, cek apakah dimensinya di-constrain ke "
                          "ReferencePlane tetap/Origin family, bukan ke Point.")
        for l in lines:
            output.print_md(l)

    # ==============================================================
    # === VERIFIED EVIDENCE ===
    # ==============================================================
    output.print_md("\n---\n### === VERIFIED EVIDENCE ===")
    if not verified_evidence:
        output.print_md("(none collected)")
    for v in verified_evidence:
        output.print_md("- {}".format(v))
    output.print_md("- Form count = {}, ReferencePlane count = {}, Sketch count = {}, "
                     "ReferencePoint count = {}, NestedFamilyInstance count = {}".format(
                         len(form_summaries), len(ref_plane_data), len(sketch_data),
                         len(all_ref_points), len(nested_instances)))

    # ==============================================================
    # === UNKNOWN / API LIMITATIONS ===
    # ==============================================================
    output.print_md("\n### === UNKNOWN / API LIMITATIONS ===")
    for u in unknown_items:
        output.print_md("- {}".format(u))
    output.print_md("- Orientation-specific dependency (terpisah dari POSITION/EXISTENCE): TIDAK TERSEDIA "
                     "lewat API publik apa pun yang dipakai di sini -- selalu UNKNOWN.")
    output.print_md("- Formula/constraint parametrik internal tanpa element reference eksplisit TIDAK "
                     "tercakup oleh GetDependentElements() -- kemungkinan ada dependency yang tidak "
                     "terlihat sama sekali oleh tool ini.")

    # ==============================================================
    # === POSSIBLE ROOT-CAUSE HYPOTHESES ===
    # ==============================================================
    output.print_md("\n### === POSSIBLE ROOT-CAUSE HYPOTHESES ===")
    output.print_md("**EVIDENCE-BACKED** (didukung langsung oleh data di atas):")
    no_relation_forms = [fs["id"] for fs in form_summaries
                          if not form_construction[fs["id"]]["point_relation"]
                          and not form_construction[fs["id"]]["direct_point_hits"]]
    with_relation_forms = [fs["id"] for fs in form_summaries
                            if form_construction[fs["id"]]["point_relation"]
                            or form_construction[fs["id"]]["direct_point_hits"]]
    if with_relation_forms and no_relation_forms:
        output.print_md("- CAMPURAN ditemukan: Form {} punya evidence dependency ke Adaptive Point "
                         "(lewat chain atau BFS langsung), sedangkan Form {} TIDAK punya evidence apa pun "
                         "-- evidence-backed CANDIDATE untuk 'sebagian geometry terhubung, sebagian tidak', "
                         "konsisten dengan hasil visual RotatedCellGeometryExperiment (hanya sebagian "
                         "geometry mengikuti perpindahan corner). TIDAK menyimpulkan ini SATU-SATUNYA "
                         "penyebab.".format(", ".join(with_relation_forms), ", ".join(no_relation_forms)))
    elif no_relation_forms and not with_relation_forms:
        output.print_md("- SEMUA Form ({}) tidak punya evidence dependency langsung ke Point manapun -- "
                         "evidence-backed CANDIDATE bahwa construction chain-nya TIDAK tertangkap oleh "
                         "GetDependentElements() sama sekali (lihat UNKNOWN section: mungkin formula/"
                         "constraint parametrik yang tidak terekspos API).".format(", ".join(no_relation_forms)))
    elif with_relation_forms and not no_relation_forms:
        output.print_md("- SEMUA Form ({}) punya evidence dependency ke Point -- TIDAK ADA kandidat "
                         "'geometry terputus' yang evidence-backed dari data ini saja.".format(
                             ", ".join(with_relation_forms)))
    else:
        output.print_md("- (Tidak cukup data Form untuk kandidat evidence-backed apa pun.)")

    output.print_md("\n**HYPOTHESIS** (belum terbukti oleh API evidence di atas, perlu konfirmasi visual "
                     "langsung di Family Editor UI):")
    output.print_md("- Form yang chain-nya UNKNOWN mungkin dibangun dari Sketch yang di-constrain ke "
                     "ReferencePlane 'host'/tetap (bukan ReferencePlane yang reachable dari Point manapun) "
                     "-- BELUM DIBUKTIKAN, perlu klik langsung tiap ReferencePlane di Family Editor untuk "
                     "cek 'Is Reference'/constraint-nya.")
    if nested_instances:
        output.print_md("- Nested FamilyInstance yang tercatat di atas mungkin membawa geometry yang tidak "
                         "terhubung ke Adaptive Point induk -- BELUM DIBUKTIKAN.")
    output.print_md("- Formula/parameter driving yang tidak terlihat oleh GetDependentElements() bisa jadi "
                     "penyebab sebagian geometry 'terkunci' -- HYPOTHESIS, tidak dapat diverifikasi oleh "
                     "tool berbasis GetDependentElements() apa pun.")

finally:
    if family_doc_opened_here and work_doc is not None:
        try:
            work_doc.Close(False)
            output.print_md("\n---\n*Family document yang dibuka oleh tool ini sudah ditutup TANPA "
                             "disimpan (Close(False)).*")
        except Exception as ex:
            output.print_md("\n---\n*PERINGATAN: gagal menutup family document: {}. Tidak ada perubahan "
                             "yang disimpan oleh tool ini.*".format(ex))

output.print_md("\n---\nSTOP. Read-only introspection + reflection only. Tidak ada family, geometry, "
                 "adaptive point, reference plane, sketch, parameter, schema, atau production change yang "
                 "dibuat. Tidak ada root-cause final disimpulkan -- lihat pemisahan VERIFIED EVIDENCE vs "
                 "UNKNOWN vs HYPOTHESIS di atas. Jangan mengubah rotation implementation berdasarkan hasil "
                 "ini. Tunggu hasil run sebelum melangkah lebih jauh.")
