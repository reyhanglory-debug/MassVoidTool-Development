# -*- coding: utf-8 -*-
"""
Adaptive Family Geometry Dependency Diagnostic
------------------------------------------------------------------
TUJUAN -- SATU dan HANYA SATU

RotatedCellGeometryExperiment membuktikan bahwa memindahkan POSISI 4
corner cell (Rodrigues rotation, TANPA SetCoordinateSystem()) berhasil
memindahkan keempat Adaptive Point Tinggi Kaki tepat 45.0000 deg --
tetapi geometry Tinggi Kaki TIDAK ikut berotasi sebagai satu rigid
body: sebagian geometry/corner berubah, sebagian lagi tetap pada
orientasi lama.

Tool ini TIDAK mengulang eksperimen rotasi apa pun. Tool ini membuka
family document (Family Editor) dan MEMETAKAN, dengan Revit API
evidence saja (bukan tebakan, bukan nama elemen, bukan visual saja):

    ELEMENT GEOMETRY (Form) mana yang punya bukti dependency
    (POSITION/EXISTENCE, via GetDependentElements()) terhadap
    ADAPTIVE PLACEMENT POINT mana.

Tool ini TIDAK menggantikan, TIDAK mewarisi kode dari, dan TIDAK
memodifikasi diagnostic mana pun sebelumnya (termasuk
FamilyDocumentIntrospection, yang menjawab pertanyaan ORIENTATION-
dependency secara umum). Diagnostic ini FOKUS BERBEDA: memetakan
dependency PER-POINT <-> PER-FORM secara eksplisit dua-arah (forward
table per Point, reverse table per Form), termasuk BFS multi-hop
(Point -> ReferencePlane/Curve/Sketch -> Form) karena
GetDependentElements() pada Revit API TIDAK dijamin transitif/lengkap
dalam satu panggilan -- serta memeriksa Nested Family Instance secara
terpisah. Berdiri sendiri, sepenuhnya terpisah dari diagnostic lain.

------------------------------------------------------------------
LOCKED FILES -- HANYA fungsi baca-nama yang dipanggil apa adanya
------------------------------------------------------------------
    mass_panel_core.py  (get_family_name, get_type_name -- HANYA
                          dipakai untuk membaca nama Family/Type dari
                          FamilySymbol; TIDAK ADA fungsi core lain
                          yang dipanggil di file ini karena diagnostic
                          ini tidak menyentuh Mass Face / grid / cell
                          sama sekali)

mass_panel_rotation.py, mass_panel_storage.py, mass_panel_storage_v5.py
TIDAK di-import sama sekali di file ini. Tidak ada Extensible Storage
dibaca/ditulis, tidak ada Schema/Entity apa pun.

Tidak ada ElementTransformUtils.RotateElement(), Transform.CreateRotation(),
Transform.CreateRotationAtPoint(), ReferencePoint.SetCoordinateSystem(),
atau AdaptiveComponentFamilyUtils.SetPointOrientationType() dipakai di
mana pun di sini. Tool ini TIDAK membuat, TIDAK menghapus, dan TIDAK
mengubah geometry, adaptive point, reference plane, sketch, parameter,
atau elemen family apa pun.

------------------------------------------------------------------
BAGAIMANA FAMILY DOCUMENT DIBUKA (READ-ONLY GUARANTEE)
------------------------------------------------------------------
Dua mode, dipilih otomatis:

1. Jika DOCUMENT AKTIF SAAT INI sudah Family Document (Anda sudah
   membuka .rfa di Family Editor secara manual): tool memakai
   document tersebut LANGSUNG. Tidak ada dokumen lain dibuka/ditutup.

2. Jika document aktif adalah Project Document: tool meminta Anda
   memilih SATU Adaptive Family yang loaded di project (forms.
   SelectFromList -- Anda yang menentukan, TIDAK ada default/auto-
   pick), lalu memanggil `Document.EditFamily(family)` -- API resmi
   Revit untuk membuka family document DALAM MEMORI. Family document
   sementara ini:
       - TIDAK PERNAH di-Save().
       - TIDAK PERNAH di-load-back ke project (tidak ada
         LoadFamily()/LoadFamilyIntoProject() dipanggil).
       - Ditutup TANPA disimpan (`familyDoc.Close(False)`) di akhir
         tool ini, di dalam blok `finally` -- dijamin tertutup bahkan
         kalau terjadi error di tengah jalan.
   Project document TIDAK PERNAH disentuh oleh mode ini sama sekali.

Dalam KEDUA mode: satu-satunya operasi tulis yang pernah terjadi pada
family document adalah panggilan Element.GetDependentElements(), yang
pada sebagian versi Revit API secara historis membutuhkan Transaction
terbuka untuk dieksekusi sama sekali (lihat FamilyDocumentIntrospection
dan V5StorageDiagnostic -- konvensi yang sama dipakai di sini).
Transaction tersebut SELALU di-RollBack() di blok finally -- TIDAK ADA
perubahan yang pernah di-Commit ke family document, baik yang dibuka
manual maupun via EditFamily().

------------------------------------------------------------------
KENAPA GetDependentElements() DAN BUKAN NAMA ELEMEN
------------------------------------------------------------------
Per instruksi eksplisit: nama Reference Plane/Sketch/Form TIDAK PERNAH
dipakai sebagai bukti dependency di tool ini. Satu-satunya API publik
yang melaporkan dependency edge ANTAR ELEMEN adalah
Element.GetDependentElements(ElementFilter), yang mengembalikan setiap
elemen yang akan terhapus jika elemen sumber dihapus -- yaitu bukti
POSITION/EXISTENCE yang dapat diverifikasi.

GetDependentElements() TIDAK membuktikan bahwa geometry FORM bereaksi
terhadap ORIENTATION Point (BasisX/BasisY/BasisZ) -- ia hanya
membuktikan keterkaitan POSITION/EXISTENCE. Di mana pun label ini
dipakai dalam laporan, itu SELALU berarti POSITION/EXISTENCE, TIDAK
PERNAH orientation. Revit API publik tidak mengekspos dependency edge
yang spesifik untuk orientation, terpisah dari existence-dependency
ini -- karena itu setiap kali evidence tidak cukup, tool ini mencetak
UNKNOWN, bukan menebak YES/NO.

GetDependentElements() TIDAK dijamin transitif (Point->Form langsung
belum tentu muncul walau Point->Curve->Form terhubung tidak langsung).
Karena itu tool ini melakukan BFS multi-hop dari setiap Point
(Point -> level-1 dependents -> level-2 dependents -> ... hingga
kedalaman terbatas) untuk mencari SEMUA elemen yang reachable dari
Point tersebut lewat rantai GetDependentElements(), dan baru menandai
YES pada Form yang ditemukan di reachable-set tersebut. Kedalaman/
jumlah node traversal DIBATASI (lihat MAX_BFS_DEPTH / MAX_BFS_VISITED)
untuk mencegah runaway pada family yang sangat besar -- kalau limit
tercapai sebelum traversal selesai, hasil untuk Point tersebut ditandai
TRAVERSAL INCOMPLETE dan Form yang belum terjangkau dilaporkan UNKNOWN
(bukan NO), supaya limit traversal tidak disalahartikan sebagai bukti
tidak-ada-dependency.

PENTING -- batas evidence ini SELALU dinyatakan eksplisit di laporan:
- YES  = Form ditemukan di reachable-set BFS dari Point (POSITION/
         EXISTENCE dependency evidence, BUKAN orientation).
- NO   = Form TIDAK ditemukan di reachable-set BFS dari Point yang
         traversal-nya selesai penuh (LENGKAP, tidak truncated).
         Ini TIDAK membuktikan tidak-ada-dependency secara mutlak --
         GetDependentElements() mungkin tidak mencakup semua relasi
         parametrik internal (mis. formula/constraint tanpa element
         reference eksplisit) -- hanya berarti tidak ada BUKTI yang
         ditemukan lewat API ini.
- UNKNOWN = traversal dari Point tersebut GAGAL (exception) atau
            TRUNCATED (limit tercapai) sebelum bisa memastikan
            reachability ke Form tersebut.

------------------------------------------------------------------
YANG SENGAJA TIDAK DILAKUKAN DI SINI (per instruksi user)
------------------------------------------------------------------
- TIDAK ADA perubahan pada mass_panel_core.py, mass_panel_rotation.py,
  mass_panel_storage.py, mass_panel_storage_v5.py, production file,
  atau diagnostic lama mana pun.
- TIDAK ADA family/geometry/parameter yang dibuat, dihapus, atau diubah.
- TIDAK ADA SetCoordinateSystem(), SetPointOrientationType(),
  RotateElement(), CreateRotation(), atau CreateRotationAtPoint().
- TIDAK ADA Extensible Storage / Schema / Entity apa pun.
- TIDAK ADA family di-Save() atau di-load-back ke project.
- TIDAK ADA kesimpulan root-cause FINAL. Bagian "POSSIBLE ROOT-CAUSE
  CANDIDATES" secara eksplisit memisahkan evidence-backed (didukung
  bukti GetDependentElements()/API langsung di laporan ini) dari
  hypothesis (belum terbukti, perlu dikonfirmasi user secara visual
  di Family Editor) -- dan TIDAK PERNAH menyatakan salah satu sebagai
  benar/final.
"""

from pyrevit import revit, DB, forms, script

from mass_panel_core import get_family_name, get_type_name

doc = revit.doc
uidoc = revit.uidoc
output = script.get_output()

MAX_BFS_DEPTH = 6
MAX_BFS_VISITED = 800

output.print_md("## Adaptive Family Geometry Dependency Diagnostic")
output.print_md(
    "Read-only, development-only. Tool ini memetakan dependency POSITION/EXISTENCE "
    "(Element.GetDependentElements(), TIDAK PERNAH diklaim sebagai bukti orientation "
    "dependency) antara Adaptive Placement Point dan geometry/Form di dalam family "
    "document. Tidak ada geometry/family/parameter yang dibuat, dihapus, atau diubah. "
    "Tidak ada kesimpulan root-cause final dicetak.")


# ==================================================================
# Generic read-only helpers (standalone -- tidak di-share dengan file
# diagnostic lain).
# ==================================================================
def fmt_eid(eid):
    if eid is None:
        return "None"
    try:
        return str(int(eid.Value))
    except Exception:
        pass
    try:
        return str(int(eid.IntegerValue))
    except Exception:
        pass
    return str(eid)


def fmt_xyz(p):
    if p is None:
        return "None"
    try:
        return "({:.6f}, {:.6f}, {:.6f})".format(p.X, p.Y, p.Z)
    except Exception:
        return str(p)


def safe_attr(obj, name):
    try:
        return getattr(obj, name), None
    except Exception as ex:
        return None, str(ex)


def safe_call(fn):
    try:
        return fn(), None
    except Exception as ex:
        return None, str(ex)


# ==================================================================
# STEP 0: Obtain a Family Document -- read-only in both modes (see
# docstring). `family_doc_opened_here` tracks whether THIS tool opened
# it (and must therefore close it, unsaved, when done).
# ==================================================================
family_doc_opened_here = False
work_doc = None

if doc.IsFamilyDocument:
    work_doc = doc
    output.print_md("\n**Mode: document aktif SUDAH Family Document** -- dipakai langsung, "
                     "tidak ada document lain dibuka/ditutup oleh tool ini.")
else:
    output.print_md("\n**Mode: document aktif adalah Project Document** -- tool akan membuka "
                     "SATU Adaptive Family via Document.EditFamily() (in-memory, read-only, "
                     "TIDAK disimpan, TIDAK di-load-back ke project).")

    candidates = DB.FilteredElementCollector(doc).OfClass(DB.FamilySymbol).ToElements()
    family_map = {}  # label (family name) -> DB.Family
    for sym in candidates:
        try:
            if sym.Family.FamilyPlacementType != DB.FamilyPlacementType.Adaptive:
                continue
        except Exception:
            continue
        fam_name = get_family_name(sym)
        if fam_name not in family_map:
            family_map[fam_name] = sym.Family

    if not family_map:
        forms.alert(
            "Tidak ada Adaptive Family yang loaded di project ini. Load family yang ingin "
            "diinspeksi (mis. Tinggi Kaki) lalu jalankan ulang tool ini, atau buka .rfa-nya "
            "langsung di Family Editor sebelum menjalankan tool ini.",
            title="Tidak ada Adaptive Family", exitscript=True)

    fam_labels = sorted(family_map.keys())
    chosen_fam_label = forms.SelectFromList.show(
        fam_labels,
        title="PILIH Adaptive Family untuk dibuka & diinspeksi di Family Editor "
              "(mis. 'Tinggi Kaki') -- Anda yang menentukan, tool ini TIDAK auto-pick",
        button_name="Buka di Family Editor (read-only)", multiselect=False)
    if chosen_fam_label is None:
        script.exit()

    target_family = family_map[chosen_fam_label]
    output.print_md("Family dipilih: **{}** (dipilih manual oleh user).".format(chosen_fam_label))

    try:
        work_doc = doc.EditFamily(target_family)
        family_doc_opened_here = True
    except Exception as ex:
        output.print_md("**GAGAL membuka family via Document.EditFamily(): {}**".format(ex))
        script.exit()

    output.print_md("Family document dibuka in-memory via Document.EditFamily() -- "
                     "TIDAK disimpan, TIDAK di-load-back ke project. Akan ditutup tanpa "
                     "disimpan (Close(False)) di akhir tool ini.")


# ==================================================================
# Everything below runs inside try/finally so that, if THIS tool
# opened the family document, it is ALWAYS closed unsaved -- even on
# an unexpected error.
# ==================================================================
try:
    # ==============================================================
    # STEP 1: Family Document identity.
    # ==============================================================
    output.print_md("\n---\n### 1. FAMILY DOCUMENT IDENTITY")

    is_fam_doc = work_doc.IsFamilyDocument
    output.print_md("- Document Title: **{}**".format(work_doc.Title))
    output.print_md("- IsFamilyDocument: **{}**".format(is_fam_doc))

    if not is_fam_doc:
        output.print_md(
            "\n**STOP -- document obtained is NOT a Family Document.** Tidak ada evidence "
            "lebih lanjut yang dapat dikumpulkan oleh tool ini. Tidak ada perubahan dibuat.")
        script.exit()

    # ==============================================================
    # STEP 2: OwnerFamily identity.
    # ==============================================================
    output.print_md("\n### 2. OWNER FAMILY")

    owner_family, owner_err = safe_attr(work_doc, "OwnerFamily")
    if owner_err or owner_family is None:
        output.print_md("- OwnerFamily: FAILED to read ({})".format(owner_err or "returned None"))
    else:
        try:
            fam_name_disp = owner_family.Name
        except Exception as ex:
            fam_name_disp = "UNKNOWN (.Name raised: {})".format(ex)
        output.print_md("- Family Name: **{}**".format(fam_name_disp))

        cat, cat_err = safe_call(lambda: owner_family.FamilyCategory.Name)
        output.print_md("- Category: **{}**".format(cat if not cat_err else "UNKNOWN ({})".format(cat_err)))

        placement_type, pt_err = safe_attr(owner_family, "FamilyPlacementType")
        output.print_md("- FamilyPlacementType: **{}**".format(
            placement_type if not pt_err else "UNKNOWN ({})".format(pt_err)))

    is_adaptive_fam, iaf_err = safe_call(
        lambda: DB.AdaptiveComponentFamilyUtils.IsAdaptiveComponentFamily(work_doc))
    output.print_md("- IsAdaptiveComponentFamily(work_doc) [official API, runtime-verified, "
                     "NOT assumed]: **{}**".format(
                         is_adaptive_fam if not iaf_err else "UNKNOWN (API call raised: {})".format(iaf_err)))

    # ==============================================================
    # STEP 3: Adaptive Points.
    # ==============================================================
    output.print_md("\n### 3. ADAPTIVE PLACEMENT POINTS")

    adaptive_point_ids, ap_err = safe_call(
        lambda: list(DB.AdaptiveComponentFamilyUtils.GetAdaptivePoints(work_doc)))
    if ap_err:
        output.print_md("GetAdaptivePoints(work_doc) FAILED: {}".format(ap_err))
        adaptive_point_ids = []
    elif not adaptive_point_ids:
        output.print_md("GetAdaptivePoints(work_doc) returned an EMPTY list -- no adaptive "
                         "placement points found (or this is not recognized as an Adaptive "
                         "Component family by the API).")
    else:
        output.print_md("GetAdaptivePoints(work_doc) returned **{}** point(s). Placement Number "
                         "below = index in THIS returned list (0-based) -- the public API exposes "
                         "no separate placement-index property; list order is the only ordering "
                         "evidence available (same convention as FamilyDocumentIntrospection)."
                         .format(len(adaptive_point_ids)))

    points_data = []  # list of dict
    for idx, pt_id in enumerate(adaptive_point_ids):
        pt_el = work_doc.GetElement(pt_id)
        entry = {"index": idx, "id": pt_id, "element": pt_el}

        position, pos_err = safe_attr(pt_el, "Position")
        entry["position"] = position
        entry["position_err"] = pos_err

        cs, cs_err = safe_call(lambda el=pt_el: el.GetCoordinateSystem())
        entry["cs"] = cs
        entry["cs_err"] = cs_err

        orient_type, orient_err = safe_call(
            lambda p=pt_id: DB.AdaptiveComponentFamilyUtils.GetPointOrientationType(work_doc, p))
        entry["orient_type"] = orient_type
        entry["orient_err"] = orient_err

        constraint_type, constraint_err = safe_call(
            lambda p=pt_id: DB.AdaptiveComponentFamilyUtils.GetPointConstraintType(work_doc, p))
        entry["constraint_type"] = constraint_type
        entry["constraint_err"] = constraint_err

        points_data.append(entry)

        output.print_md("\n**Point #{}** -- ElementId {}".format(idx, fmt_eid(pt_id)))
        output.print_md("- Placement Number = {} (list-order evidence only, see note above)".format(idx))
        if pos_err:
            output.print_md("- Position: FAILED to read ({})".format(pos_err))
        else:
            output.print_md("- Position: {}".format(fmt_xyz(position)))
        if cs_err:
            output.print_md("- CoordinateSystem: FAILED to read ({})".format(cs_err))
        else:
            output.print_md("- CoordinateSystem Origin={}, BasisX={}, BasisY={}, BasisZ={}".format(
                fmt_xyz(cs.Origin), fmt_xyz(cs.BasisX), fmt_xyz(cs.BasisY), fmt_xyz(cs.BasisZ)))
        output.print_md("- Orientation Type (GetPointOrientationType): {}".format(
            orient_type if not orient_err else "UNKNOWN (API call raised: {})".format(orient_err)))
        output.print_md("- Point Constraint Type (GetPointConstraintType): {}".format(
            constraint_type if not constraint_err else "UNKNOWN (API call raised: {})".format(constraint_err)))

    # ==============================================================
    # STEP 4: Enumerate geometry/Form elements + nested FamilyInstance.
    # ==============================================================
    output.print_md("\n### 4. GEOMETRY / FORM ELEMENTS")

    forms_elems = list(DB.FilteredElementCollector(work_doc).OfClass(DB.GenericForm))
    # FreeFormElement may not exist on every RevitAPI version -- guarded.
    freeform_elems = []
    try:
        freeform_elems = list(DB.FilteredElementCollector(work_doc).OfClass(DB.FreeFormElement))
    except Exception:
        freeform_elems = []
    all_form_elems = list(forms_elems) + list(freeform_elems)

    ref_planes = list(DB.FilteredElementCollector(work_doc).OfClass(DB.ReferencePlane))
    curve_elems = list(DB.FilteredElementCollector(work_doc).OfClass(DB.CurveElement))
    sketches = list(DB.FilteredElementCollector(work_doc).OfClass(DB.Sketch))
    nested_instances = list(DB.FilteredElementCollector(work_doc).OfClass(DB.FamilyInstance))

    if not all_form_elems:
        output.print_md("No GenericForm / FreeFormElement found in this family document.")

    def collect_solids(geometry_element):
        """Read-only recursive Solid collection, own-file implementation
        (does not call/import any function from other diagnostics)."""
        solids = []
        if geometry_element is None:
            return solids
        for obj in geometry_element:
            if isinstance(obj, DB.Solid):
                try:
                    if obj.Volume > 1e-9:
                        solids.append(obj)
                except Exception:
                    continue
            elif isinstance(obj, DB.GeometryInstance):
                try:
                    inst_geom = obj.GetInstanceGeometry()
                except Exception:
                    continue
                solids.extend(collect_solids(inst_geom))
        return solids

    def geometry_summary(elem):
        result = {"solid_count": 0, "total_volume": 0.0, "bbox_min": None, "bbox_max": None,
                  "references_available": None, "error": None}
        try:
            opts = DB.Options()
            opts.ComputeReferences = True
            opts.IncludeNonVisibleObjects = False
            opts.DetailLevel = DB.ViewDetailLevel.Fine
            geom = elem.get_Geometry(opts)
            if geom is None:
                result["error"] = "get_Geometry() returned None"
                return result
            solids = collect_solids(geom)
            result["solid_count"] = len(solids)
            total_vol = 0.0
            all_pts = []
            refs_found = False
            for s in solids:
                try:
                    total_vol += s.Volume
                except Exception:
                    pass
                try:
                    for f in s.Faces:
                        try:
                            if f.Reference is not None:
                                refs_found = True
                        except Exception:
                            pass
                except Exception:
                    pass
                try:
                    for e in s.Edges:
                        try:
                            crv = e.AsCurve()
                            for pt in crv.Tessellate():
                                all_pts.append((pt.X, pt.Y, pt.Z))
                        except Exception:
                            continue
                except Exception:
                    pass
            result["total_volume"] = total_vol
            result["references_available"] = refs_found
            if all_pts:
                xs = [p[0] for p in all_pts]
                ys = [p[1] for p in all_pts]
                zs = [p[2] for p in all_pts]
                result["bbox_min"] = (min(xs), min(ys), min(zs))
                result["bbox_max"] = (max(xs), max(ys), max(zs))
        except Exception as ex:
            result["error"] = str(ex)
        return result

    form_summaries = []
    for fe in all_form_elems:
        fe_id_str = fmt_eid(fe.Id)
        runtime_type = fe.GetType().Name
        cat, cat_err = safe_call(lambda f=fe: f.Category.Name)
        gs = geometry_summary(fe)

        form_summaries.append({"element": fe, "id": fe_id_str, "runtime_type": runtime_type,
                                "geom": gs})

        output.print_md("\n**{} {}**".format(runtime_type, fe_id_str))
        output.print_md("- Category: {}".format(cat if not cat_err else "UNKNOWN ({})".format(cat_err)))
        if gs["error"]:
            output.print_md("- Geometry: FAILED to read ({})".format(gs["error"]))
        else:
            output.print_md("- Solid count = {}, Total volume = {:.6f} ft3".format(
                gs["solid_count"], gs["total_volume"]))
            if gs["bbox_min"]:
                output.print_md("- BoundingBox Min = {}, Max = {}".format(
                    "({:.6f}, {:.6f}, {:.6f})".format(*gs["bbox_min"]),
                    "({:.6f}, {:.6f}, {:.6f})".format(*gs["bbox_max"])))
            output.print_md("- Geometry References available (Options.ComputeReferences=True, "
                             "Face.Reference != None found on at least one Face) = {}".format(
                                 gs["references_available"]))

    # ==============================================================
    # STEP 5: GetDependentElements() -- direct (level-1) evidence for
    # points, PLUS full BFS multi-hop reachability per point.
    # Wrapped in a Transaction that is ALWAYS rolled back (same
    # convention as FamilyDocumentIntrospection / V5StorageDiagnostic).
    # ==============================================================
    output.print_md("\n### 5. DEPENDENCY EVIDENCE (Element.GetDependentElements() -- "
                     "POSITION/EXISTENCE ONLY, NOT ORIENTATION)")

    point_direct_deps = {}    # point index -> set(fmt_eid) or None on error
    point_direct_deps_err = {}
    point_reachable = {}      # point index -> set(fmt_eid) reachable via BFS
    point_bfs_truncated = {}  # point index -> bool

    if adaptive_point_ids:
        t = DB.Transaction(work_doc, "READ-ONLY dependency introspection (always rolled back)")
        t.Start()
        try:
            def get_dependents_of(eid):
                el = work_doc.GetElement(eid)
                if el is None:
                    return None, "GetElement returned None"
                deps, err = safe_call(lambda e=el: list(e.GetDependentElements(None)))
                return deps, err

            for idx, pt_id in enumerate(adaptive_point_ids):
                deps, err = get_dependents_of(pt_id)
                if err:
                    point_direct_deps[idx] = None
                    point_direct_deps_err[idx] = err
                    point_reachable[idx] = set()
                    point_bfs_truncated[idx] = False
                    continue
                dep_keys = set(fmt_eid(d) for d in deps)
                point_direct_deps[idx] = dep_keys
                point_direct_deps_err[idx] = None

                # BFS multi-hop from this point's direct dependents.
                visited = set([fmt_eid(pt_id)]) | set(dep_keys)
                reachable = set(dep_keys)
                frontier = list(deps)
                depth = 0
                truncated = False
                while frontier and depth < MAX_BFS_DEPTH:
                    next_frontier = []
                    for node_id in frontier:
                        n_deps, n_err = get_dependents_of(node_id)
                        if n_err or n_deps is None:
                            continue
                        for nd in n_deps:
                            key = fmt_eid(nd)
                            if key not in visited:
                                visited.add(key)
                                reachable.add(key)
                                next_frontier.append(nd)
                                if len(visited) > MAX_BFS_VISITED:
                                    truncated = True
                                    break
                        if truncated:
                            break
                    if truncated:
                        break
                    frontier = next_frontier
                    depth += 1
                if frontier and depth >= MAX_BFS_DEPTH:
                    truncated = True

                point_reachable[idx] = reachable
                point_bfs_truncated[idx] = truncated
        finally:
            t.RollBack()

    output.print_md("*(GetDependentElements() evidence + BFS traversal gathered inside a "
                     "Transaction that was immediately rolled back -- zero changes committed to "
                     "the family document, regardless of source mode.)*")
    output.print_md("BFS traversal limits: MAX_BFS_DEPTH={}, MAX_BFS_VISITED={} (per point). "
                     "If reached, that point's result is marked TRAVERSAL INCOMPLETE below, and "
                     "Forms not yet reached by it are reported UNKNOWN (not NO).".format(
                         MAX_BFS_DEPTH, MAX_BFS_VISITED))

    # ------------------------------------------------------------
    # 5a. Forward table: POINT N -> Position + Dependent elements
    # (direct/level-1 only, classified by category -- this is the
    # table format requested: "ReferencePlane X / Curve X / Form X").
    # ------------------------------------------------------------
    output.print_md("\n#### 5a. Forward table -- per Point (direct/level-1 dependents only)")

    rp_by_id = {fmt_eid(r.Id): r for r in ref_planes}
    curve_by_id = {fmt_eid(c.Id): c for c in curve_elems}
    sketch_by_id = {fmt_eid(s.Id): s for s in sketches}
    form_by_id = {f["id"]: f for f in form_summaries}
    nested_by_id = {fmt_eid(n.Id): n for n in nested_instances}

    for idx, pt_id in enumerate(adaptive_point_ids):
        entry = points_data[idx]
        output.print_md("\n**POINT {}** (ElementId {})".format(idx, fmt_eid(pt_id)))
        output.print_md("  Position: {}".format(
            fmt_xyz(entry["position"]) if not entry["position_err"] else "UNKNOWN"))

        err = point_direct_deps_err.get(idx)
        deps = point_direct_deps.get(idx)
        if err:
            output.print_md("  Dependent elements: GetDependentElements() FAILED -- {}".format(err))
            continue
        if not deps:
            output.print_md("  Dependent elements: NONE (GetDependentElements() returned an "
                             "empty set -- POSITION ONLY / no verified downstream element).")
            continue

        lines = []
        for key in deps:
            if key in rp_by_id:
                lines.append("- ReferencePlane {}".format(key))
            elif key in curve_by_id:
                lines.append("- Curve/CurveElement {} ({})".format(key, curve_by_id[key].GetType().Name))
            elif key in sketch_by_id:
                lines.append("- Sketch {}".format(key))
            elif key in form_by_id:
                lines.append("- Form {} ({})".format(key, form_by_id[key]["runtime_type"]))
            elif key in nested_by_id:
                lines.append("- NestedFamilyInstance {}".format(key))
            else:
                lines.append("- (other element) {}".format(key))
        output.print_md("  Dependent elements:\n" + "\n".join("    " + l for l in lines))

        if point_bfs_truncated.get(idx):
            output.print_md("  ** BFS traversal from this Point was TRUNCATED (limit reached) -- "
                             "reachable-set below may be INCOMPLETE. **")
        output.print_md("  Full reachable-set via BFS (multi-hop, all element types) = "
                         "{} element(s) total.".format(len(point_reachable.get(idx, set()))))

    # ------------------------------------------------------------
    # 5b. Reverse mapping: FORM -> Point 1..N = YES/NO/UNKNOWN.
    # ------------------------------------------------------------
    output.print_md("\n#### 5b. Reverse mapping -- per Form")

    form_point_matrix = {}  # form_id -> {point_idx: "YES"/"NO"/"UNKNOWN"}
    for fs in form_summaries:
        f_id = fs["id"]
        row = {}
        for idx, pt_id in enumerate(adaptive_point_ids):
            if point_direct_deps_err.get(idx):
                row[idx] = "UNKNOWN"
                continue
            reachable = point_reachable.get(idx, set())
            truncated = point_bfs_truncated.get(idx, False)
            if f_id in reachable:
                row[idx] = "YES"
            elif truncated:
                row[idx] = "UNKNOWN"
            else:
                row[idx] = "NO"
        form_point_matrix[f_id] = row

        output.print_md("\n**FORM {} ({})**".format(f_id, fs["runtime_type"]))
        output.print_md("  Dependent on:")
        for idx in range(len(adaptive_point_ids)):
            output.print_md("    Point {} = {}".format(idx, row[idx]))

    if not form_summaries:
        output.print_md("No Forms found -- no reverse mapping to report.")

    # ==============================================================
    # STEP 6: Nested Family Instances.
    # ==============================================================
    output.print_md("\n### 6. NESTED FAMILY INSTANCES")

    if not nested_instances:
        output.print_md("No nested FamilyInstance elements found in this family document.")
    else:
        for ni in nested_instances:
            ni_id_str = fmt_eid(ni.Id)
            sym, sym_err = safe_attr(ni, "Symbol")
            if sym_err or sym is None:
                nested_fam_name = "UNKNOWN"
                nested_type_name = "UNKNOWN"
            else:
                nested_fam_name = get_family_name(sym)
                nested_type_name = get_type_name(sym)
            transform, tf_err = safe_call(lambda e=ni: e.GetTransform())

            output.print_md("\n**NestedFamilyInstance {}**".format(ni_id_str))
            output.print_md("- Family Name: {}".format(nested_fam_name))
            output.print_md("- Type Name: {}".format(nested_type_name))
            if tf_err:
                output.print_md("- Transform: FAILED to read ({})".format(tf_err))
            else:
                output.print_md("- Transform Origin={}, BasisX={}, BasisY={}, BasisZ={}".format(
                    fmt_xyz(transform.Origin), fmt_xyz(transform.BasisX),
                    fmt_xyz(transform.BasisY), fmt_xyz(transform.BasisZ)))
            output.print_md("- Apakah transform ini menjelaskan mengapa sebagian geometry tidak "
                             "ikut berotasi: **TIDAK DISIMPULKAN DI SINI** -- ini raw evidence saja; "
                             "lihat POSSIBLE ROOT-CAUSE CANDIDATES di bawah untuk status "
                             "evidence-backed vs hypothesis.")

    # ==============================================================
    # STEP 7: Geometry without any direct-dependency evidence --
    # flagged explicitly.
    # ==============================================================
    output.print_md("\n### 7. GEOMETRY WITHOUT DIRECT (LEVEL-1) POINT DEPENDENCY EVIDENCE")

    flagged = []
    for fs in form_summaries:
        f_id = fs["id"]
        has_direct = False
        for idx, pt_id in enumerate(adaptive_point_ids):
            deps = point_direct_deps.get(idx)
            if deps and f_id in deps:
                has_direct = True
                break
        if not has_direct:
            flagged.append(fs)

    if not form_summaries:
        output.print_md("No Forms found.")
    elif not flagged:
        output.print_md("Every Form has at least one direct (level-1) dependency edge to some "
                         "Adaptive Point per GetDependentElements().")
    else:
        for fs in flagged:
            row = form_point_matrix.get(fs["id"], {})
            any_indirect_yes = any(v == "YES" for v in row.values())
            note = ("HOWEVER reachable via multi-hop BFS (see 5b reverse mapping -- indirect "
                    "POSITION/EXISTENCE evidence found)." if any_indirect_yes else
                    "NO multi-hop BFS evidence found either (see 5b) -- no dependency evidence "
                    "of any kind to any Adaptive Point in this family document.")
            output.print_md("- FORM {} ({}): no DIRECT dependency edge to any Point. {}".format(
                fs["id"], fs["runtime_type"], note))

    # ==============================================================
    # STEP 8: Summary sections.
    # ==============================================================
    output.print_md("\n---\n### === VERIFIED EVIDENCE ===")
    output.print_md("- IsFamilyDocument = {}".format(is_fam_doc))
    output.print_md("- IsAdaptiveComponentFamily(work_doc) = {}".format(
        is_adaptive_fam if not iaf_err else "UNKNOWN"))
    output.print_md("- Adaptive Point count (GetAdaptivePoints) = {}".format(len(adaptive_point_ids)))
    output.print_md("- Form/GenericForm/FreeFormElement count = {}".format(len(form_summaries)))
    output.print_md("- Nested FamilyInstance count = {}".format(len(nested_instances)))
    output.print_md("- Per-Point direct dependency evidence: lihat bagian 5a di atas (raw "
                     "GetDependentElements() sets, tidak diinterpretasikan).")
    output.print_md("- Per-Form reverse mapping (YES/NO/UNKNOWN per Point, via BFS multi-hop "
                     "POSITION/EXISTENCE reachability): lihat bagian 5b di atas.")
    output.print_md("- Semua evidence di atas adalah POSITION/EXISTENCE dependency (Element."
                     "GetDependentElements()) -- BUKAN orientation dependency. Tidak ada API publik "
                     "yang dipakai/tersedia di tool ini yang membuktikan reaksi terhadap BasisX/"
                     "BasisY/BasisZ Point secara terpisah dari Origin/posisinya.")

    output.print_md("\n### === UNKNOWN / API LIMITATION ===")
    output.print_md("- Orientation-specific dependency (terpisah dari POSITION/EXISTENCE): TIDAK "
                     "TERSEDIA lewat API publik manapun yang dipakai di sini -- selalu UNKNOWN.")
    output.print_md("- Setiap Point dengan GetPointOrientationType()/GetPointConstraintType() yang "
                     "gagal (exception) dilaporkan UNKNOWN pada bagian 3 di atas -- tidak ditebak.")
    output.print_md("- Setiap Point dengan traversal BFS TRUNCATED dilaporkan UNKNOWN untuk Form "
                     "yang belum terjangkau (bagian 5b) -- limit traversal TIDAK disalahartikan "
                     "sebagai bukti tidak-ada-dependency.")
    output.print_md("- 'Profile/Sketch source' internal sebuah Form (curve mana persisnya yang "
                     "membentuk profile) tidak diekspos API publik apa pun yang dipakai di sini -- "
                     "hanya membership dalam reachable-set BFS yang tersedia sebagai evidence.")
    output.print_md("- Formula/constraint parametrik internal (tanpa element reference eksplisit) "
                     "TIDAK tercakup oleh GetDependentElements() -- kemungkinan ada dependency yang "
                     "TIDAK terlihat sama sekali oleh tool ini.")

    output.print_md("\n### === POSSIBLE ROOT-CAUSE CANDIDATES ===")
    output.print_md("**EVIDENCE-BACKED** (didukung langsung oleh data di atas):")
    any_no_direct_no_indirect = any(
        not any(v == "YES" for v in form_point_matrix.get(fs["id"], {}).values())
        for fs in form_summaries) if form_summaries else False
    if form_summaries and adaptive_point_ids:
        output.print_md("- Lihat tabel reverse mapping (5b): Form mana pun yang menunjukkan "
                         "campuran YES pada sebagian Point dan NO/UNKNOWN pada Point lain adalah "
                         "evidence-backed CANDIDATE untuk 'geometry ini hanya sebagian terhubung "
                         "ke placement point' -- TANPA menyimpulkan bahwa ini penyebab rigid-body "
                         "rotation gagal; itu memerlukan konfirmasi visual di Family Editor.")
        if any_no_direct_no_indirect:
            output.print_md("- Ada minimal satu Form TANPA evidence dependency (direct maupun BFS) "
                             "ke Point mana pun sama sekali (lihat bagian 7) -- evidence-backed "
                             "CANDIDATE bahwa Form tersebut TIDAK dikontrol oleh adaptive point "
                             "manapun lewat mekanisme yang terlihat oleh GetDependentElements().")
    else:
        output.print_md("- (Tidak cukup data Point/Form untuk kandidat evidence-backed apa pun.)")

    output.print_md("\n**HYPOTHESIS** (belum terbukti oleh API evidence di atas, perlu konfirmasi "
                     "visual langsung di Family Editor UI):")
    output.print_md("- Kemungkinan pola: Geometry A terhubung ke Point 1+2+3+4 sekaligus (mengikuti "
                     "quadrilateral secara penuh), sedangkan Geometry B terhubung ke Reference Plane "
                     "'host'/'loop system' yang independen dari Point -- BELUM DIBUKTIKAN oleh "
                     "GetDependentElements() saja; harus dicek constraint/dimension driving di "
                     "Family Editor UI secara visual.")
    if nested_instances:
        output.print_md("- Nested FamilyInstance yang tercatat di bagian 6 MUNGKIN membawa geometry "
                         "yang tidak langsung terhubung ke Adaptive Point induk (mis. posisinya "
                         "dikunci relatif terhadap Reference Plane lokal, bukan terhadap Point) -- "
                         "BELUM DIBUKTIKAN; transform mentah sudah dicetak di bagian 6, interpretasi "
                         "efeknya terhadap rotasi HYPOTHESIS SAJA.")
    output.print_md("- Formula/parameter driving (tidak terlihat oleh GetDependentElements()) bisa "
                     "jadi penyebab sebagian geometry 'terkunci' pada orientasi lama -- HYPOTHESIS, "
                     "tidak dapat diverifikasi oleh tool berbasis GetDependentElements() apa pun.")

finally:
    if family_doc_opened_here and work_doc is not None:
        try:
            work_doc.Close(False)
            output.print_md("\n---\n*Family document yang dibuka oleh tool ini (via EditFamily()) "
                             "sudah ditutup TANPA disimpan (Close(False)).*")
        except Exception as ex:
            output.print_md("\n---\n*PERINGATAN: gagal menutup family document yang dibuka tool ini: "
                             "{}. Tidak ada perubahan yang disimpan oleh tool ini -- Close() hanya "
                             "membebaskan resource in-memory.*".format(ex))

output.print_md("\n---\nSTOP. Tool ini HANYA melakukan read-only introspection. Tidak ada family, "
                 "geometry, adaptive point, reference plane, sketch, parameter, schema, atau "
                 "production change yang dibuat. Tidak ada root-cause final yang disimpulkan -- "
                 "lihat pemisahan EVIDENCE-BACKED vs HYPOTHESIS di atas. Per instruksi, tunggu hasil "
                 "run ini sebelum melangkah lebih jauh.")
