# -*- coding: utf-8 -*-
"""
mass_panel_rotation.py
------------------------------------------------------------------
NEW / ADDITIVE module for the Rotation feature. Does NOT modify,
import-and-monkeypatch, or depend on any change to mass_panel_core.py
or mass_panel_storage.py -- both remain byte-identical to the locked
production versions.

This module answers exactly one question: given an orthonormal
surface frame (a Transform whose BasisX/BasisY/BasisZ come straight
out of the LOCKED get_surface_coordinate_system(), unmodified),
return a NEW frame with the same Origin and the same BasisZ, but with
BasisX/BasisY rotated by a user-specified angle WITHIN that point's
own local tangent plane, about that point's OWN normal (BasisZ) as
axis.

DECISION RECORD (per user approval):
  - Rotation axis  = each corner's OWN BasisZ (per-corner), NOT a
    single shared cell-center axis. This guarantees the rotated frame
    stays exactly orthonormal at every point regardless of surface
    curvature (see module docstring in the audit response for the
    full rationale).
  - Rotation is applied to ORIENTATION ONLY. Position (Origin) is
    never touched here -- callers must keep placement point XYZ
    (P00/P10/P11/P01, from classify_cell()'s corner_xyz) completely
    untouched; this module never receives or returns a position.
  - No dependency on Transform.CreateRotation / CreateRotationAtPoint
    / ElementTransformUtils.RotateElement. Pure vector math (Rodrigues'
    rotation formula) using DB.XYZ operations only, so behavior does
    not depend on which Transform-construction overloads a given
    Revit/pyRevit/IronPython combination happens to expose.

CONVENTION:
    0 deg   = frame unchanged (current production orientation).
    +angle  = rotate BasisX toward BasisY (i.e. counter-clockwise
              when viewed from the +BasisZ side looking back at the
              surface, per the right-handed frame BasisZ = BasisX x BasisY
              already guaranteed by get_surface_coordinate_system()).
    -angle  = the reverse.
    Angle is degrees at every public function boundary in this module.
"""

import math
from pyrevit import DB


def _rodrigues_rotate_vector(v, axis, angle_rad):
    """Rotate vector v about unit vector `axis` by angle_rad radians,
    using Rodrigues' rotation formula:

        v_rot = v*cos(t) + (axis x v)*sin(t) + axis*(axis.v)*(1-cos(t))

    `axis` here is always frame.BasisZ, and `v` is always frame.BasisX
    or frame.BasisY -- both already perpendicular to BasisZ (Gram-
    Schmidt result of the LOCKED get_surface_coordinate_system()), so
    axis.DotProduct(v) is ~0 and the formula reduces to a pure in-plane
    rotation. The full formula is kept (not the reduced 2-term form)
    as a defensive correctness check: if axis and v are ever NOT
    perpendicular (e.g. a caller passes a non-orthonormal frame by
    mistake), this still returns a mathematically well-defined
    rotation instead of a silently wrong shortcut.
    """
    cos_t = math.cos(angle_rad)
    sin_t = math.sin(angle_rad)
    axis_dot_v = axis.DotProduct(v)
    term1 = v.Multiply(cos_t)
    term2 = axis.CrossProduct(v).Multiply(sin_t)
    term3 = axis.Multiply(axis_dot_v * (1.0 - cos_t))
    return term1.Add(term2).Add(term3)


def rotate_frame_in_plane(frame, angle_degrees):
    """Return a NEW DB.Transform: same Origin, same BasisZ as `frame`,
    with BasisX/BasisY rotated in-plane by angle_degrees about
    frame.BasisZ (this point's OWN normal).

    `frame` must be the unmodified return value of the LOCKED
    get_surface_coordinate_system(face, u, v) -- this function reads
    BasisX/BasisY/BasisZ/Origin from it and does not call, wrap, or
    alter that function in any way.

    Never touches Origin -- placement point position is entirely the
    caller's responsibility (classify_cell()'s corner_xyz, untouched).
    """
    angle_rad = math.radians(float(angle_degrees))
    axis = frame.BasisZ  # this point's OWN normal -- per-corner axis, per user decision

    if angle_degrees == 0:
        # Fast path, and guarantees byte-for-byte identical output to
        # "no rotation" at the exact 0 deg default -- no trigonometric
        # rounding noise introduced when rotation is left at production
        # default.
        new_x = frame.BasisX
        new_y = frame.BasisY
    else:
        new_x = _rodrigues_rotate_vector(frame.BasisX, axis, angle_rad)
        new_y = _rodrigues_rotate_vector(frame.BasisY, axis, angle_rad)

    tr = DB.Transform.Identity
    tr.Origin = frame.Origin
    tr.BasisX = new_x
    tr.BasisY = new_y
    tr.BasisZ = frame.BasisZ
    return tr


def frame_diagnostics(frame):
    """Return a dict of orthogonality/length/handedness checks for one
    frame -- used by RotationDiagnostic to print verifiable numbers
    rather than just asserting correctness. Pure read-only inspection,
    no mutation."""
    x, y, z = frame.BasisX, frame.BasisY, frame.BasisZ
    return {
        "x_dot_y": x.DotProduct(y),
        "x_dot_z": x.DotProduct(z),
        "y_dot_z": y.DotProduct(z),
        "len_x": x.GetLength(),
        "len_y": y.GetLength(),
        "len_z": z.GetLength(),
        # Handedness: cross(X,Y).Z should be ~+1.0 for a right-handed,
        # non-reflected orthonormal frame (this is also exactly what
        # the LOCKED get_surface_coordinate_system() already guarantees
        # by construction: BasisZ = BasisX.CrossProduct(BasisY)). A
        # value near -1.0 would mean the rotation flipped handedness
        # (a reflection, not a rotation) -- Rodrigues' formula applied
        # to BasisX/BasisY about their own BasisZ cannot produce that,
        # but this check makes it verifiable at runtime rather than
        # assumed.
        "handedness": x.CrossProduct(y).DotProduct(z),
    }
