# -*- coding: utf-8 -*-
"""
mass_panel_core.py
------------------------------------------------------------------
SATU-SATUNYA classifier untuk seluruh MassVoidTool extension.

Semua tool (2c, 2e, 2f, dan tool berikutnya) HARUS memanggil
classify_cell() dari sini. Jangan menulis ulang logika 9-sample di
masing-masing script.py.

Sumber logika: diambil dari Tool 2e/2f (yang terbukti benar), BUKAN
dari Tool 2c lama -- 2c punya bug counter-correction:

    status = "ERROR" if status != "ERROR" else status

baris itu no-op (selalu assign status ke dirinya sendiri), sehingga
downgrade ke ERROR saat corner Evaluate() gagal TIDAK PERNAH terjadi
di 2c, dan koreksi counter (count_valid -= 1, dst) di baris berikutnya
jadi dead code. Ini penyebab selisih 2c (96 VALID/4 PARTIAL) vs
2f (97 VALID/3 PARTIAL). Modul ini mengikuti urutan 2f yang benar:

    1. 9x Face.IsInside() -> tentukan VALID/PARTIAL/VOID/ERROR(sampling)
    2. HANYA kalau status == VALID: Face.Evaluate() 4 corner
    3. Kalau ada corner Evaluate() gagal -> downgrade status ke ERROR
       SEBELUM counter caller di-increment (caller cukup
       counts[result["status"]] += 1 satu kali, tidak ada koreksi
       counter terpisah).

Tidak ada perubahan pada:
  - urutan sample fraction [0.0, 0.5, 1.0]
  - urutan corner P00 -> P10 -> P11 -> P01
  - definisi UV bounding box / du / dv

Jangan mengganti algoritma ini tanpa alasan kuat (lihat handoff §4, §5).
"""

from pyrevit import DB

SAMPLE_FRACS = [0.0, 0.5, 1.0]


def is_inside(face, u, v):
    """True/False kalau IsInside() berhasil dievaluasi, None kalau exception."""
    try:
        return bool(face.IsInside(DB.UV(u, v)))
    except Exception:
        return None


def evaluate(face, u, v):
    """XYZ kalau Evaluate() berhasil, None kalau exception."""
    try:
        return face.Evaluate(DB.UV(u, v))
    except Exception:
        return None


def get_uv_grid_params(face, nu, nv):
    """Hitung umin/umax/vmin/vmax/du/dv dari face.GetBoundingBox().
    Dipakai bersama oleh semua tool supaya definisi grid selalu identik."""
    bbox_uv = face.GetBoundingBox()
    umin, umax = bbox_uv.Min.U, bbox_uv.Max.U
    vmin, vmax = bbox_uv.Min.V, bbox_uv.Max.V
    du = (umax - umin) / float(nu)
    dv = (vmax - vmin) / float(nv)
    return umin, umax, vmin, vmax, du, dv


def classify_cell(face, u0, u1, v0, v1):
    """
    Klasifikasi SATU cell UV [u0,u1] x [v0,v1] pada `face`.

    Return dict:
        {
            "status": "VALID" | "PARTIAL" | "VOID" | "ERROR",
            "sample_status": { (uf, vf): True|False|None, ... },  # 9 entries
            "corner_xyz": { "00":XYZ, "10":XYZ, "11":XYZ, "01":XYZ } | None,
            "error_detail": str | None,
        }

    Caller HANYA melakukan:
        result = classify_cell(face, u0, u1, v0, v1)
        counts[result["status"]] += 1

    Jangan menambahkan logika koreksi counter terpisah di caller --
    itulah bug yang sedang diperbaiki modul ini.
    """
    sample_status = {}
    has_sample_error = False
    vals = []

    for uf in SAMPLE_FRACS:
        for vf in SAMPLE_FRACS:
            su = u0 + (u1 - u0) * uf
            sv = v0 + (v1 - v0) * vf
            st = is_inside(face, su, sv)
            sample_status[(uf, vf)] = st
            if st is None:
                has_sample_error = True
            else:
                vals.append(st)

    error_detail = None

    if has_sample_error:
        status = "ERROR"
        error_detail = "IsInside() gagal pada minimal satu sample point."
    elif all(vals):
        status = "VALID"
    elif not any(vals):
        status = "VOID"
    else:
        status = "PARTIAL"

    corner_xyz = None
    if status == "VALID":
        corner_xyz = {
            "00": evaluate(face, u0, v0),
            "10": evaluate(face, u1, v0),
            "11": evaluate(face, u1, v1),
            "01": evaluate(face, u0, v1),
        }
        if any(p is None for p in corner_xyz.values()):
            # Downgrade ke ERROR SEBELUM caller increment counter apa pun --
            # tidak ada "koreksi counter" terpisah, karena caller belum
            # pernah menghitung status VALID untuk cell ini.
            status = "ERROR"
            error_detail = "Face.Evaluate() gagal pada minimal satu corner."
            corner_xyz = None

    return {
        "status": status,
        "sample_status": sample_status,
        "corner_xyz": corner_xyz,
        "error_detail": error_detail,
    }


def get_family_name(symbol):
    """Baca FamilyName tanpa memakai Element.Name langsung -- HINDARI
    Element.Name (explicit interface implementation -> MissingMemberException
    di IronPython, sudah terbukti dan diperbaiki di Tool 2d/2e/2f)."""
    try:
        fn = symbol.FamilyName
        if fn:
            return fn
    except Exception:
        pass
    try:
        p = symbol.get_Parameter(DB.BuiltInParameter.ALL_MODEL_FAMILY_NAME)
        if p is not None:
            val = p.AsString()
            if val:
                return val
    except Exception:
        pass
    try:
        fam = symbol.Family
        p2 = fam.get_Parameter(DB.BuiltInParameter.ALL_MODEL_FAMILY_NAME)
        if p2 is not None:
            val2 = p2.AsString()
            if val2:
                return val2
    except Exception:
        pass
    return "<FamilyName tidak terbaca>"


def get_type_name(symbol):
    """Baca TypeName tanpa memakai Element.Name langsung (lihat get_family_name)."""
    try:
        p = symbol.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM)
        if p is not None:
            val = p.AsString()
            if val:
                return val
    except Exception:
        pass
    try:
        p2 = symbol.get_Parameter(DB.BuiltInParameter.ALL_MODEL_TYPE_NAME)
        if p2 is not None:
            val2 = p2.AsString()
            if val2:
                return val2
    except Exception:
        pass
    try:
        return "<TypeName tidak terbaca -- Id {}>".format(symbol.Id)
    except Exception:
        return "<TypeName tidak terbaca>"


def get_surface_coordinate_system(face, u, v):
    """
    Return an orthonormal surface frame at UV(u,v).

    BasisX = tangent along surface U.
    BasisY = surface V tangent orthogonalized against BasisX.
    BasisZ = rebuilt normal, aligned to Face.ComputeNormal(UV).

    This does not move the point; it only supplies an orientation frame
    for ReferencePoint.SetCoordinateSystem().
    """
    uv = DB.UV(u, v)
    deriv = face.ComputeDerivatives(uv)
    normal = face.ComputeNormal(uv)

    x = deriv.BasisX
    y_raw = deriv.BasisY

    if x.IsZeroLength() or y_raw.IsZeroLength() or normal.IsZeroLength():
        raise Exception("Surface derivative returned a zero-length vector.")

    x = x.Normalize()

    y = y_raw - x.Multiply(x.DotProduct(y_raw))
    if y.IsZeroLength():
        raise Exception("U/V surface tangents are degenerate at UV({},{}).".format(u, v))
    y = y.Normalize()

    z = x.CrossProduct(y)
    if z.IsZeroLength():
        raise Exception("Unable to construct surface normal at UV({},{}).".format(u, v))
    z = z.Normalize()

    if z.DotProduct(normal) < 0:
        y = y.Multiply(-1.0)
        z = x.CrossProduct(y).Normalize()

    tr = DB.Transform.Identity
    tr.Origin = face.Evaluate(uv)
    tr.BasisX = x
    tr.BasisY = y
    tr.BasisZ = z
    return tr
