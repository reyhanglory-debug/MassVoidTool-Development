# -*- coding: utf-8 -*-
"""
mass_panel_storage_v5.py
------------------------------------------------------------------
NEW / ADDITIVE schema for the Rotation feature. Replaces the v4
attempt as the active development schema.

Schema v3 (mass_panel_storage.py, GUID 60C54BDE-7D44-431F-A79C-
CE26982FA1BF) is NOT modified, NOT deleted, and NOT imported in a way
that changes its behavior -- this module only reads its public
GENERATOR_ID constant and element_id_to_str()/_normalize_mass_id_str()
helpers (single source of truth for the ElementId cross-version
logic). No field, GUID, or function inside mass_panel_storage.py is
altered.

Schema v4 (mass_panel_storage_v4.py, GUID 2F6B9C41-8E7D-4A2B-9F3C-
1D5E7A8B4C6F) is NOT reused, NOT modified, and NOT deleted. Per the
user's own diagnostic (V4StorageDiagnostic: "Schema v4 creation/
lookup" and "Schema v4 GUID matches expected" both reported PASS,
while "Entity creation" -- i.e. Entity.Set[Double]("RotationAngle",
...) -- reported FAIL with "The unit unitTypeId is not compatible
with the field description"), the field description actually
registered under that GUID in the live Schema registry cannot be
trusted to match what mass_panel_storage_v4.py's source currently
says it should be: Schema.Lookup(GUID) in ensure_schema_v4() returns
whatever was already Finish()'d for that GUID (Extensible Storage
schemas are immutable, and the in-process Schema registry is keyed by
GUID regardless of which script/version originally created the
entry) without ever re-running the field-definition code, so a PASS
on "creation/lookup" does not prove the CURRENT source produced the
field. Per this project's own versioning rule (schemas cannot have
their field definitions changed once Finish()'d -- see
mass_panel_storage.py's v1->v2->v3 history), GUID
2F6B9C41-8E7D-4A2B-9F3C-1D5E7A8B4C6F is retired as a known-bad/
untrusted historical experiment and never reused.

------------------------------------------------------------------
WHY A NEW SCHEMA / NEW GUID (not "fix v4 in place")
------------------------------------------------------------------
Extensible Storage schemas are immutable once Finish()'d. GUID
2F6B9C41-... may already carry a corrupted/incompatible field
description for RotationAngle in the live registry, so no code change
to mass_panel_storage_v4.py could ever repair entities created against
that GUID. A clean GUID is required.

------------------------------------------------------------------
WHY RotationAngle IS System.String HERE (not System.Double)
------------------------------------------------------------------
RotationAngle is METADATA, not identity, and is never used for
unit-aware arithmetic inside Extensible Storage itself -- the
rotation math (Rodrigues' formula, in mass_panel_rotation.py) always
happens in-memory in plain Python floats/degrees, never by reading
this stored field back into a calculation that depends on Revit's
internal unit system. Making the field a Double therefore bought
nothing except a dependency on FieldBuilder unit-spec APIs
(SetSpec/SpecTypeId or SetUnitType/UnitType) whose availability and
exact required argument type (ForgeTypeId vs. legacy enum) varies
across Revit API versions -- which is what produced the v4 failure.

Per the user's decision: RotationAngle is stored as a plain
System.String holding the DEGREES value formatted as text (e.g.
"0.0", "45.0", "90.0", "180.0"). This field needs NO unit spec at
all -- SetSpec / SpecTypeId / SetUnitType / UnitType / UT_Angle /
unitTypeId do not appear anywhere in this module. Any Revit version
that can build a String field (already proven by schema v3, which is
11/12 String+Int32 fields) can build this schema; there is no
version-dependent unit API surface left to fail.

Round-tripping is exact string equality (no float/degrees<->radians
conversion, no rounding), by design.

------------------------------------------------------------------
BACKWARD COMPATIBILITY WITH v3 -- REQUIRED BEHAVIOR
------------------------------------------------------------------
RotationAngle is METADATA, not identity -- exactly like GridU/GridV/
FamilyName/TypeName/CellU/CellV/BatchId in v3. Replace Existing must
still find old v3 panels by GeneratorId+SourceMassId+SourceFaceStableRep
alone, whether the OLD panels were written by schema v3 or v5, and
regardless of what Rotation value the NEW batch uses.

Finding "existing panels" across schema versions is intentionally NOT
solved inside this module -- see find_existing_generated_panels_v5()
docstring below for why that stays a caller-side concern for now
(unchanged from the v4 module's approach).
"""

from Autodesk.Revit.DB.ExtensibleStorage import Schema, SchemaBuilder, Entity, AccessLevel
import System

from mass_panel_storage import (
    GENERATOR_ID,
    element_id_to_str,
    _normalize_mass_id_str,
)

SCHEMA_GUID = System.Guid("3ECA0FE8-258B-4589-A122-8A77140186AC")
SCHEMA_NAME = "MassVoidTool_GeneratedPanel_v5"
SCHEMA_VERSION = "5"

FIELD_NAMES = [
    "GeneratorId", "SchemaVersion", "SourceMassId", "SourceFaceStableRep",
    "GridU", "GridV", "FamilyName", "TypeName", "BatchId",
    "CellU", "CellV", "TotalCells", "RotationAngle",
]


def ensure_schema_v5():
    """Lookup schema v5 kalau sudah pernah dibuat di document/session
    ini; kalau belum, buat baru. RotationAngle adalah System.String --
    TIDAK ADA field Double di schema ini, sehingga TIDAK ADA
    pemanggilan SetSpec/SpecTypeId/SetUnitType/UnitType sama sekali di
    seluruh modul ini."""
    schema = Schema.Lookup(SCHEMA_GUID)
    if schema:
        return schema
    sb = SchemaBuilder(SCHEMA_GUID)
    sb.SetSchemaName(SCHEMA_NAME)
    sb.SetReadAccessLevel(AccessLevel.Public)
    sb.SetWriteAccessLevel(AccessLevel.Public)
    sb.AddSimpleField("GeneratorId", System.String)
    sb.AddSimpleField("SchemaVersion", System.String)
    sb.AddSimpleField("SourceMassId", System.String)
    sb.AddSimpleField("SourceFaceStableRep", System.String)
    sb.AddSimpleField("GridU", System.Int32)
    sb.AddSimpleField("GridV", System.Int32)
    sb.AddSimpleField("FamilyName", System.String)
    sb.AddSimpleField("TypeName", System.String)
    sb.AddSimpleField("BatchId", System.String)
    sb.AddSimpleField("CellU", System.Int32)
    sb.AddSimpleField("CellV", System.Int32)
    sb.AddSimpleField("TotalCells", System.Int32)
    sb.AddSimpleField("RotationAngle", System.String)
    return sb.Finish()


def make_entity_v5(schema, mass_id, face_stable, nu, nv, fam_name, type_name,
                     batch_id, cell_u, cell_v, rotation_angle_deg):
    """Bangun Entity schema v5. Sama persis dengan make_entity() versi
    v3 ditambah RotationAngle -- disimpan sebagai STRING desimal
    degrees (mis. "45.0"), bukan Double/radians. Tidak ada konversi
    unit di sini; str() apa adanya."""
    e = Entity(schema)
    e.Set[System.String]("GeneratorId", GENERATOR_ID)
    e.Set[System.String]("SchemaVersion", SCHEMA_VERSION)
    e.Set[System.String]("SourceMassId", _normalize_mass_id_str(mass_id))
    e.Set[System.String]("SourceFaceStableRep", face_stable)
    e.Set[System.Int32]("GridU", int(nu))
    e.Set[System.Int32]("GridV", int(nv))
    e.Set[System.String]("FamilyName", fam_name)
    e.Set[System.String]("TypeName", type_name)
    e.Set[System.String]("BatchId", batch_id)
    e.Set[System.Int32]("CellU", int(cell_u))
    e.Set[System.Int32]("CellV", int(cell_v))
    e.Set[System.Int32]("TotalCells", int(nu) * int(nv))
    e.Set[System.String]("RotationAngle", str(float(rotation_angle_deg)))
    return e


def read_entity_v5(element, schema):
    """Baca entity schema v5 dari satu elemen. RotationAngle dibaca
    apa adanya sebagai string degrees (caller yang butuh float boleh
    float() sendiri; modul ini tidak memaksakan konversi). Return
    dict, atau None kalau elemen tidak punya entity valid untuk
    schema ini."""
    try:
        e = element.GetEntity(schema)
        if not e.IsValid():
            return None
        return {
            "GeneratorId": e.Get[System.String]("GeneratorId"),
            "SchemaVersion": e.Get[System.String]("SchemaVersion"),
            "SourceMassId": e.Get[System.String]("SourceMassId"),
            "SourceFaceStableRep": e.Get[System.String]("SourceFaceStableRep"),
            "GridU": e.Get[System.Int32]("GridU"),
            "GridV": e.Get[System.Int32]("GridV"),
            "FamilyName": e.Get[System.String]("FamilyName"),
            "TypeName": e.Get[System.String]("TypeName"),
            "BatchId": e.Get[System.String]("BatchId"),
            "CellU": e.Get[System.Int32]("CellU"),
            "CellV": e.Get[System.Int32]("CellV"),
            "TotalCells": e.Get[System.Int32]("TotalCells"),
            "RotationAngle": e.Get[System.String]("RotationAngle"),
        }
    except Exception:
        return None


def find_existing_generated_panels_v5(doc, DB, schema, mass_id, face_stable):
    """Cari elemen yang punya entity schema v5 milik plugin ini, untuk
    Mass/Face tertentu. Identity SAMA PERSIS dengan v3:
    GeneratorId + SourceMassId + SourceFaceStableRep -- TIDAK
    difilter oleh Grid/Family/Type/Rotation.

    NOTE -- cross-version lookup (v3 + v5 together): this function
    only looks at schema v5 entities. Finding a MIXED set (some panels
    written as v3, some as v5, on the same Mass/Face) is intentionally
    left to the caller: call this function AND mass_panel_storage's
    find_existing_generated_panels() (with the v3 schema) separately,
    then merge the two element lists. Schema v4 is retired/untrusted
    and is never queried by production or by this module. That keeps
    this module fully decoupled from mass_panel_storage.py (no shared
    find function, no risk of an edit here ever touching v3 behavior)
    -- the merge is a one-line list concatenation at the call site,
    done once you approve the diagnostic results, not before."""
    mass_id_str = _normalize_mass_id_str(mass_id)
    found = []
    elems = DB.FilteredElementCollector(doc).WhereElementIsNotElementType().ToElements()
    for el in elems:
        data = read_entity_v5(el, schema)
        if not data:
            continue
        if data["GeneratorId"] != GENERATOR_ID:
            continue
        if data["SourceMassId"] != mass_id_str:
            continue
        if data["SourceFaceStableRep"] != face_stable:
            continue
        found.append(el)
    return found
