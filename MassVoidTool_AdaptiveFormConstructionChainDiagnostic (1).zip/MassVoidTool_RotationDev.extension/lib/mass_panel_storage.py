# -*- coding: utf-8 -*-
"""
mass_panel_storage.py
------------------------------------------------------------------
SATU-SATUNYA definisi ExtensibleStorage schema untuk panel yang
dibuat MassVoidTool. Dipakai bersama oleh:

  - 4D-MassPanelGeneratorProduction
  - 4D-ExtensibleStorageDiagnostic

Jangan menulis ulang SchemaBuilder / field list di script.py manapun.

------------------------------------------------------------------
SCHEMA v3 (GUID BARU -- SourceMassId sekarang String)
------------------------------------------------------------------
Schema v1 ("...v2" lama, GUID 9A0F7C2E-...) punya CenterU/CenterV
Double tanpa unit -> SchemaBuilder.Finish() gagal ("Units are
required for field CenterU"). Field itu dihapus di schema v2 (GUID
C3E7A1F0-..., SourceMassId masih Int32).

Schema v2 kemudian gagal juga: `instance.Id.IntegerValue` melempar
AttributeError di Revit versi ini, karena ElementId.IntegerValue
(Int32) sudah dihapus dari Revit API (diganti ElementId.Value,
Int64, sejak Revit 2024; dihapus total di Revit 2025+).

SourceMassId sekarang disimpan sebagai System.String (representasi
desimal dari ElementId), BUKAN Int32 atau Int64 -- lihat penjelasan
di dekat element_id_to_str() di bawah. Karena ini perubahan TIPE
field (bukan cuma hapus field), dipakai GUID BARU lagi + SchemaVersion
"3". Schema v1 dan v2 TIDAK dihapus/disentuh -- immutable, dan
proyek lama (kalau ada) yang sudah memakainya tetap utuh.

Field schema v3 (SEMUA String kecuali Grid/Cell/Total yang Int32):

    GeneratorId          System.String
    SchemaVersion         System.String
    SourceMassId          System.String   <- berubah dari Int32
    SourceFaceStableRep   System.String
    GridU                 System.Int32
    GridV                 System.Int32
    FamilyName            System.String
    TypeName              System.String
    BatchId               System.String
    CellU                 System.Int32
    CellV                 System.Int32
    TotalCells            System.Int32
"""

from Autodesk.Revit.DB.ExtensibleStorage import Schema, SchemaBuilder, Entity, AccessLevel
import System

SCHEMA_GUID = System.Guid("60C54BDE-7D44-431F-A79C-CE26982FA1BF")
SCHEMA_NAME = "MassVoidTool_GeneratedPanel_v3"
SCHEMA_VERSION = "3"
GENERATOR_ID = "MassVoidTool"

FIELD_NAMES = [
    "GeneratorId", "SchemaVersion", "SourceMassId", "SourceFaceStableRep",
    "GridU", "GridV", "FamilyName", "TypeName", "BatchId",
    "CellU", "CellV", "TotalCells",
]


# ------------------------------------------------------------------
# ElementId cross-version handling
# ------------------------------------------------------------------
# Revit <=2023  : ElementId.IntegerValue exists (Int32).
# Revit 2024    : both IntegerValue (Int32, deprecated) and Value (Int64)
#                 exist.
# Revit 2025+   : IntegerValue REMOVED entirely -- only .Value (Int64)
#                 exists. This is what caused:
#                     AttributeError: 'ElementId' object has no
#                     attribute 'IntegerValue'
#
# SourceMassId is therefore stored as System.String (decimal digits of
# the id), NOT System.Int32 and NOT System.Int64. Reasons:
#   1. A fixed-width integer field (Int32 or Int64) bakes in an
#      assumption about ElementId's underlying width. Revit already
#      changed that width once (Int32 -> Int64 in 2024); a String
#      field never needs another schema migration if it changes again.
#   2. SourceMassId is only ever used for equality comparison
#      (find_existing_generated_panels), never arithmetic -- a string
#      compares just as correctly as a number for that purpose.
#   3. Int32 risks silent overflow/truncation on very large models on
#      newer Revit versions where raw ids can exceed 2^31-1; String
#      has no such ceiling.
# This is a genuine schema change (field type), so it ships as a new
# GUID/SchemaVersion ("3") rather than mutating schema v2 in place --
# Extensible Storage schemas are immutable after Finish().


def _clr_type_name(obj):
    try:
        return str(obj.GetType().FullName)
    except Exception:
        try:
            return str(type(obj))
        except Exception:
            return "<unknown>"


def describe_element_id(eid):
    """Introspect one ElementId without raising. Returns a dict meant
    for diagnostic printing: CLR type of the ElementId itself, which
    value property is actually present, and the CLR type of that
    value. Used by 4D-ExtensibleStorageDiagnostic to show real
    environment facts instead of assuming an API version."""
    info = {
        "elementid_clr_type": _clr_type_name(eid),
        "has_value_property": hasattr(eid, "Value"),
        "has_integervalue_property": hasattr(eid, "IntegerValue"),
        "value_raw": None,
        "value_clr_type": None,
        "source_property": None,
    }
    if info["has_value_property"]:
        try:
            v = eid.Value
            info["value_raw"] = v
            info["value_clr_type"] = _clr_type_name(v)
            info["source_property"] = "Value"
            return info
        except Exception:
            pass
    if info["has_integervalue_property"]:
        try:
            v = eid.IntegerValue
            info["value_raw"] = v
            info["value_clr_type"] = _clr_type_name(v)
            info["source_property"] = "IntegerValue"
            return info
        except Exception:
            pass
    return info


def element_id_to_str(eid):
    """Cross-version-safe ElementId -> decimal string. Tries .Value
    (Revit 2024+, Int64) first, falls back to .IntegerValue (Revit
    <=2023, Int32). Raises only if an ElementId exposes neither, which
    would mean an even newer/older API shape we haven't seen yet."""
    if hasattr(eid, "Value"):
        try:
            return str(int(eid.Value))
        except Exception:
            pass
    if hasattr(eid, "IntegerValue"):
        try:
            return str(int(eid.IntegerValue))
        except Exception:
            pass
    raise Exception(
        "ElementId exposes neither .Value nor .IntegerValue -- "
        "unrecognized Revit API shape ({}).".format(_clr_type_name(eid)))


def _normalize_mass_id_str(mass_id):
    """Accept either a raw ElementId or an already-stringified id and
    return the decimal-string form used by the schema."""
    if isinstance(mass_id, str):
        return mass_id
    if hasattr(mass_id, "Value") or hasattr(mass_id, "IntegerValue"):
        return element_id_to_str(mass_id)
    return str(mass_id)


def ensure_schema():
    """Lookup schema v3 kalau sudah pernah dibuat di document ini;
    kalau belum, buat baru. Tidak ada field Double sama sekali,
    jadi tidak butuh SetUnitType()."""
    schema = Schema.Lookup(SCHEMA_GUID)
    if schema:
        return schema
    sb = SchemaBuilder(SCHEMA_GUID)
    sb.SetSchemaName(SCHEMA_NAME)
    sb.SetReadAccessLevel(AccessLevel.Public)
    sb.SetWriteAccessLevel(AccessLevel.Public)
    sb.AddSimpleField("GeneratorId", System.String)
    sb.AddSimpleField("SchemaVersion", System.String)
    sb.AddSimpleField("SourceMassId", System.String)
    sb.AddSimpleField("SourceFaceStableRep", System.String)
    sb.AddSimpleField("GridU", System.Int32)
    sb.AddSimpleField("GridV", System.Int32)
    sb.AddSimpleField("FamilyName", System.String)
    sb.AddSimpleField("TypeName", System.String)
    sb.AddSimpleField("BatchId", System.String)
    sb.AddSimpleField("CellU", System.Int32)
    sb.AddSimpleField("CellV", System.Int32)
    sb.AddSimpleField("TotalCells", System.Int32)
    return sb.Finish()


def make_entity(schema, mass_id, face_stable, nu, nv, fam_name, type_name,
                 batch_id, cell_u, cell_v):
    """Bangun Entity schema v3. mass_id boleh ElementId ATAU string
    (sudah dinormalisasi lewat _normalize_mass_id_str)."""
    e = Entity(schema)
    e.Set[System.String]("GeneratorId", GENERATOR_ID)
    e.Set[System.String]("SchemaVersion", SCHEMA_VERSION)
    e.Set[System.String]("SourceMassId", _normalize_mass_id_str(mass_id))
    e.Set[System.String]("SourceFaceStableRep", face_stable)
    e.Set[System.Int32]("GridU", int(nu))
    e.Set[System.Int32]("GridV", int(nv))
    e.Set[System.String]("FamilyName", fam_name)
    e.Set[System.String]("TypeName", type_name)
    e.Set[System.String]("BatchId", batch_id)
    e.Set[System.Int32]("CellU", int(cell_u))
    e.Set[System.Int32]("CellV", int(cell_v))
    e.Set[System.Int32]("TotalCells", int(nu) * int(nv))
    return e


def read_entity(element, schema):
    """Baca entity schema v3 dari satu elemen. Return dict atau None
    kalau elemen tidak punya entity valid untuk schema ini."""
    try:
        e = element.GetEntity(schema)
        if not e.IsValid():
            return None
        return {
            "GeneratorId": e.Get[System.String]("GeneratorId"),
            "SchemaVersion": e.Get[System.String]("SchemaVersion"),
            "SourceMassId": e.Get[System.String]("SourceMassId"),
            "SourceFaceStableRep": e.Get[System.String]("SourceFaceStableRep"),
            "GridU": e.Get[System.Int32]("GridU"),
            "GridV": e.Get[System.Int32]("GridV"),
            "FamilyName": e.Get[System.String]("FamilyName"),
            "TypeName": e.Get[System.String]("TypeName"),
            "BatchId": e.Get[System.String]("BatchId"),
            "CellU": e.Get[System.Int32]("CellU"),
            "CellV": e.Get[System.Int32]("CellV"),
            "TotalCells": e.Get[System.Int32]("TotalCells"),
        }
    except Exception:
        return None


def find_existing_generated_panels(doc, DB, schema, mass_id, face_stable,
                                     nu=None, nv=None, fam_name=None, type_name=None):
    """Cari elemen yang punya entity schema v3 milik plugin ini, untuk
    Mass/Face tertentu. mass_id boleh ElementId ATAU string.

    nu/nv/fam_name/type_name masih opsional (default None = tidak
    difilter) supaya perilaku pemanggil saat ini (yang memfilter by
    grid+family+type) tidak berubah. Redesign identity murni
    GeneratorId+SourceMassId+SourceFaceStableRep (tanpa filter grid)
    menyusul setelah diagnostic storage ini divalidasi -- BELUM
    diterapkan di sini supaya perubahan tetap isolated pada layer
    storage/schema saja untuk iterasi ini."""
    mass_id_str = _normalize_mass_id_str(mass_id)
    found = []
    elems = DB.FilteredElementCollector(doc).WhereElementIsNotElementType().ToElements()
    for el in elems:
        data = read_entity(el, schema)
        if not data:
            continue
        if data["GeneratorId"] != GENERATOR_ID:
            continue
        if data["SourceMassId"] != mass_id_str:
            continue
        if data["SourceFaceStableRep"] != face_stable:
            continue
        if nu is not None and data.get("GridU") != int(nu):
            continue
        if nv is not None and data.get("GridV") != int(nv):
            continue
        if fam_name is not None and data.get("FamilyName") != fam_name:
            continue
        if type_name is not None and data.get("TypeName") != type_name:
            continue
        found.append(el)
    return found
